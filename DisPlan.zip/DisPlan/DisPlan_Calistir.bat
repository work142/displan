@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
%PY% --version >nul 2>nul
if errorlevel 1 (
  echo Python bulunamadi. https://www.python.org/downloads/ adresinden Python 3.10+ kurun.
  echo Kurulumda "Add python.exe to PATH" kutusunu isaretlemeyi unutmayin.
  pause
  exit /b 1
)
if not exist .venv\Scripts\pythonw.exe (
  echo Ilk calistirma: gerekli paketler kuruluyor, birkac dakika surebilir...
  %PY% -m venv .venv
  if errorlevel 1 (pause & exit /b 1)
  .venv\Scripts\python -m pip install --upgrade pip
  .venv\Scripts\python -m pip install -r requirements.txt
  if errorlevel 1 (echo Kurulum basarisiz oldu. & pause & exit /b 1)
)
start "" .venv\Scripts\pythonw.exe app.py
