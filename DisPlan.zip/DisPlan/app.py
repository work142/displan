"""DişPlan — özel diş klinikleri için randevu ve hasta takip uygulaması (Windows / PySide6)."""
import datetime as dt
import os
import sys
import traceback

from PySide6.QtCore import QDate, QLibraryInfo, QSize, Qt, QTimer, QTranslator
from PySide6.QtGui import QAction, QColor, QFont, QIcon, QPainter, QPainterPath, QPixmap
from PySide6.QtWidgets import (QApplication, QComboBox, QDateEdit, QFileDialog, QHBoxLayout, QLabel,
                               QLineEdit, QMainWindow, QMenu, QMessageBox, QPushButton, QTabWidget,
                               QToolButton, QVBoxLayout, QWidget)

import db as dbm
from card import STATUS_COLORS, PatientCard
from dialogs import (AppointmentDialog, DoctorDialog, LoginDialog, PasswordDialog, PatientDialog,
                     SetupDialog, TreatmentDialog, UserDialog)
from widgets import confirm, doctor_combo, fill_table, make_table, notify, qdate_iso, selected_id

APP_NAME = "DişPlan"
DAYS = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]
MONTHS = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]

STYLE = """
QWidget { color:#263238; }
QMainWindow, QDialog { background:#f4f6f8; }
QTabWidget::pane { border:1px solid #d5dde2; background:white; border-radius:6px; top:-1px; }
QTabBar::tab { padding:9px 22px; background:#e6ecef; border:1px solid #d5dde2; border-bottom:none;
               border-top-left-radius:6px; border-top-right-radius:6px; margin-right:2px; }
QTabBar::tab:selected { background:white; font-weight:600; color:#00695c; }
QPushButton, QToolButton { padding:7px 16px; border:1px solid #b0bec5; border-radius:6px; background:white; }
QPushButton:hover, QToolButton:hover { background:#eef3f5; }
QPushButton:disabled, QToolButton:disabled { color:#b0bec5; background:#f4f6f8; }
QPushButton#primary { background:#00897b; color:white; border:1px solid #00796b; font-weight:600; }
QPushButton#primary:hover { background:#00796b; }
QPushButton#primary:disabled { background:#b2dfdb; color:white; border-color:#b2dfdb; }
QPushButton#danger { color:#c62828; }
QLineEdit, QPlainTextEdit { padding:5px 7px; border:1px solid #b0bec5; border-radius:5px; background:white; }
QLineEdit:focus, QPlainTextEdit:focus { border:1.5px solid #00897b; }
QTableWidget, QListWidget { background:white; alternate-background-color:#f7fafb; border:1px solid #d5dde2;
                            selection-background-color:#b2dfdb; selection-color:#263238; }
QHeaderView::section { background:#eceff1; padding:7px; border:none; border-bottom:1px solid #cfd8dc; font-weight:600; }
QListWidget::item:selected { background:#b2dfdb; color:#263238; border-radius:6px; }
#cardHeader { background:white; border:1px solid #d5dde2; border-radius:8px; }
#cardName { font-size:22px; font-weight:700; color:#004d40; }
#alertBox { background:#ffebee; color:#b71c1c; border:1px solid #ef9a9a; border-radius:6px; padding:7px 10px; }
#statBox { background:#f7fafb; border:1px solid #dde5e9; border-radius:8px; }
#statCap { font-size:10px; font-weight:700; color:#78909c; }
#dayTitle { font-size:18px; font-weight:700; color:#004d40; }
"""


def app_icon():
    pm = QPixmap(128, 128)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setBrush(QColor("#00897b"))
    p.setPen(Qt.PenStyle.NoPen)
    p.drawRoundedRect(4, 4, 120, 120, 28, 28)
    t = QPainterPath()
    t.moveTo(36, 42)
    t.cubicTo(36, 26, 56, 28, 64, 36)
    t.cubicTo(72, 28, 92, 26, 92, 42)
    t.cubicTo(92, 58, 84, 62, 82, 84)
    t.cubicTo(80, 100, 72, 100, 70, 84)
    t.cubicTo(68, 72, 60, 72, 58, 84)
    t.cubicTo(56, 100, 48, 100, 46, 84)
    t.cubicTo(44, 62, 36, 58, 36, 42)
    p.setBrush(QColor("white"))
    p.drawPath(t)
    p.end()
    return QIcon(pm)


def day_title(qd):
    return f"{DAYS[qd.dayOfWeek() - 1]}, {qd.day()} {MONTHS[qd.month() - 1]} {qd.year()}"


# ------------------------------------------------------------------ randevu sayfası
class AppointmentsPage(QWidget):
    def __init__(self, db, user, open_card, on_change):
        super().__init__()
        self.db, self.user, self.open_card, self.on_change = db, user, open_card, on_change
        root = QVBoxLayout(self)
        bar = QHBoxLayout()
        prev, nxt, today = QPushButton("◀"), QPushButton("▶"), QPushButton("Bugün")
        prev.clicked.connect(lambda: self._shift(-1))
        nxt.clicked.connect(lambda: self._shift(1))
        today.clicked.connect(lambda: self.date_edit.setDate(QDate.currentDate()))
        self.date_edit = QDateEdit(QDate.currentDate())
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDisplayFormat("dd.MM.yyyy")
        self.date_edit.dateChanged.connect(self.refresh)
        self.doc_filter = doctor_combo(db, allow_none=True)
        self.doc_filter.currentIndexChanged.connect(self.refresh)
        for w in (prev, self.date_edit, nxt, today):
            bar.addWidget(w)
        bar.addSpacing(20)
        bar.addWidget(QLabel("Doktor:"))
        bar.addWidget(self.doc_filter)
        bar.addStretch(1)
        root.addLayout(bar)
        self.title = QLabel()
        self.title.setObjectName("dayTitle")
        root.addWidget(self.title)
        self.table = make_table(["Saat", "Hasta", "Telefon", "Doktor", "İşlem", "Durum", "Not"], stretch=6)
        self.table.doubleClicked.connect(self._edit)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._context)
        root.addWidget(self.table, 1)

        row = QHBoxLayout()
        new = QPushButton("Yeni Randevu")
        new.setObjectName("primary")
        new.clicked.connect(self._new)
        edit = QPushButton("Düzenle")
        edit.clicked.connect(self._edit)
        card = QPushButton("Hasta Kartı")
        card.clicked.connect(self._card)
        self.status_btn = QToolButton()
        self.status_btn.setText("Durumu Değiştir ▾")
        self.status_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.status_btn.setMenu(self._status_menu())
        delete = QPushButton("Sil")
        delete.setObjectName("danger")
        delete.clicked.connect(self._delete)
        for w in (new, edit, card, self.status_btn):
            row.addWidget(w)
        row.addStretch(1)
        row.addWidget(delete)
        root.addLayout(row)
        self.refresh()

    def reload_doctors(self):
        cur = self.doc_filter.currentData()
        self.doc_filter.blockSignals(True)
        self.doc_filter.clear()
        self.doc_filter.addItem("Tüm doktorlar", None)
        for d in self.db.list_doctors():
            self.doc_filter.addItem(d["full_name"], d["id"])
        idx = self.doc_filter.findData(cur)
        self.doc_filter.setCurrentIndex(max(idx, 0))
        self.doc_filter.blockSignals(False)
        self.refresh()

    def _shift(self, days):
        self.date_edit.setDate(self.date_edit.date().addDays(days))

    def _status_menu(self):
        m = QMenu(self)
        for s in dbm.STATUSES:
            a = QAction(s, m)
            a.triggered.connect(lambda _=False, st=s: self._set_status(st))
            m.addAction(a)
        return m

    def _context(self, pos):
        if selected_id(self.table):
            m = QMenu(self)
            m.addAction("Hasta kartını aç", self._card)
            m.addAction("Düzenle", self._edit)
            sub = m.addMenu("Durumu değiştir")
            for s in dbm.STATUSES:
                sub.addAction(s, lambda st=s: self._set_status(st))
            m.exec(self.table.viewport().mapToGlobal(pos))

    def refresh(self, *_):
        qd = self.date_edit.date()
        rows = self.db.appointments_on(qdate_iso(qd), self.doc_filter.currentData())
        fill_table(self.table,
                   [(f"{r['time']} – {self._end(r)}", r["patient"], r["phone"], r["doctor"] or "—", r["procedure"],
                     r["status"], r["notes"]) for r in rows], [r["id"] for r in rows],
                   row_colors=[STATUS_COLORS.get(r["status"]) for r in rows])
        active = sum(1 for r in rows if r["status"] not in ("İptal", "Gelmedi"))
        self.title.setText(f"{day_title(qd)}   —   {active} randevu" + (f" ({len(rows) - active} iptal/gelmedi)" if len(rows) > active else ""))

    @staticmethod
    def _end(r):
        m = dbm.minutes(r["time"]) + r["duration_min"]
        return f"{m // 60 % 24:02d}:{m % 60:02d}"

    def _new(self):
        dlg = AppointmentDialog(self.db, date_iso=qdate_iso(self.date_edit.date()), doctor_id=self.doc_filter.currentData(), parent=self)
        if dlg.exec():
            self.on_change()

    def _edit(self, *_):
        aid = selected_id(self.table)
        if aid and AppointmentDialog(self.db, appt=self.db.get_appointment(aid), parent=self).exec():
            self.on_change()

    def _card(self):
        aid = selected_id(self.table)
        if aid:
            self.open_card(self.db.get_appointment(aid)["patient_id"])

    def _delete(self):
        aid = selected_id(self.table)
        if aid and confirm(self, "Randevuyu sil", "Seçili randevu silinsin mi?\n(İptal için silmek yerine durumu “İptal” yapabilirsiniz.)",
                           yes="Sil", no="Vazgeç"):
            self.db.delete_appointment(aid)
            self.on_change()

    def _set_status(self, status):
        aid = selected_id(self.table)
        if not aid:
            return
        a = self.db.get_appointment(aid)
        self.db.set_appointment_status(aid, status)
        self.on_change()
        if status == "Tamamlandı" and self.user["role"] in ("admin", "doktor") and confirm(
                self, "İşlem kaydı", "Randevu tamamlandı olarak işaretlendi.\nYapılan işlemi hasta kaydına eklemek ister misiniz?",
                yes="İşlemi Kaydet", no="Şimdi Değil"):
            dlg = TreatmentDialog(self.db, a["patient_id"], defaults={
                "date": a["date"], "doctor_id": a["doctor_id"], "procedure": a["procedure"] or "Muayene"}, parent=self)
            if dlg.exec():
                self.on_change()


# ------------------------------------------------------------------ hasta sayfası
class PatientsPage(QWidget):
    def __init__(self, db, user, open_card, on_change, close_card):
        super().__init__()
        self.db, self.user, self.open_card, self.on_change, self.close_card = db, user, open_card, on_change, close_card
        root = QVBoxLayout(self)
        bar = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Hasta ara: ad soyad, TC kimlik no veya telefon…")
        self.search.textChanged.connect(self.refresh)
        bar.addWidget(self.search, 1)
        self.count = QLabel()
        self.count.setStyleSheet("color:#607d8b")
        bar.addWidget(self.count)
        root.addLayout(bar)
        self.table = make_table(["Ad Soyad", "TC Kimlik No", "Telefon", "Yaş", "Son Yapılan İşlem", "Son İşlem Tarihi",
                                 "Son İşlemi Yapan Doktor"], stretch=0)
        self.table.doubleClicked.connect(self._card)
        root.addWidget(self.table, 1)
        row = QHBoxLayout()
        new = QPushButton("Yeni Hasta")
        new.setObjectName("primary")
        new.clicked.connect(self._new)
        card = QPushButton("Hasta Kartı")
        card.clicked.connect(self._card)
        appt = QPushButton("Randevu Ver")
        appt.clicked.connect(self._appt)
        for w in (new, card, appt):
            row.addWidget(w)
        row.addStretch(1)
        self.btn_del = QPushButton("Hastayı Sil")
        self.btn_del.setObjectName("danger")
        self.btn_del.clicked.connect(self._delete)
        self.btn_del.setEnabled(user["role"] == "admin")
        row.addWidget(self.btn_del)
        root.addLayout(row)
        self.refresh()

    def refresh(self, *_):
        rows = self.db.search_patients(self.search.text())
        fill_table(self.table,
                   [(r["full_name"], r["tc_no"], r["phone"], dbm.age_from(r["birth_date"]) if r["birth_date"] else "",
                     r["last_proc"] or "—", dbm.fmt_date(r["last_date"]), r["last_doctor"] or "—") for r in rows],
                   [r["id"] for r in rows])
        total = self.db.one("SELECT COUNT(*) c FROM patients")["c"]
        self.count.setText(f"{len(rows)} / {total} hasta")

    def _new(self):
        dlg = PatientDialog(self.db, self)
        if dlg.exec():
            self.on_change()
            self.open_card(dlg.saved_id)

    def _card(self, *_):
        pid = selected_id(self.table)
        if pid:
            self.open_card(pid)

    def _appt(self):
        pid = selected_id(self.table)
        if pid and AppointmentDialog(self.db, patient_id=pid, doctor_id=self.db.default_doctor_id(pid), parent=self).exec():
            self.on_change()

    def _delete(self):
        pid = selected_id(self.table)
        if not pid:
            return
        p = self.db.get_patient(pid)
        n = {t: self.db.one(f"SELECT COUNT(*) c FROM {t} WHERE patient_id=?", (pid,))["c"]
             for t in ("treatments", "xrays", "appointments")}
        if confirm(self, "Hastayı sil",
                   f"“{p['full_name']}” ve ona ait tüm kayıtlar KALICI olarak silinecek:\n\n"
                   f"• {n['treatments']} işlem kaydı\n• {n['xrays']} röntgen (dosyalarıyla birlikte)\n• {n['appointments']} randevu\n\n"
                   "Bu işlem geri alınamaz. Emin misiniz?", yes="Kalıcı Olarak Sil", no="Vazgeç"):
            self.close_card(pid)
            self.db.delete_patient(pid)
            self.on_change()


# ------------------------------------------------------------------ doktor sayfası
class DoctorsPage(QWidget):
    def __init__(self, db, on_change):
        super().__init__()
        self.db, self.on_change = db, on_change
        root = QVBoxLayout(self)
        self.table = make_table(["Ad Soyad", "Uzmanlık", "Telefon", "Durum"], stretch=1)
        self.table.doubleClicked.connect(self._edit)
        root.addWidget(self.table, 1)
        row = QHBoxLayout()
        new = QPushButton("Yeni Doktor")
        new.setObjectName("primary")
        new.clicked.connect(self._new)
        edit = QPushButton("Düzenle")
        edit.clicked.connect(self._edit)
        toggle = QPushButton("Aktif / Pasif Yap")
        toggle.clicked.connect(self._toggle)
        for w in (new, edit, toggle):
            row.addWidget(w)
        row.addStretch(1)
        note = QLabel("Pasif doktorlar yeni randevu listesinde görünmez; geçmiş kayıtlar korunur.")
        note.setStyleSheet("color:#78909c")
        row.addWidget(note)
        root.addLayout(row)
        self.refresh()

    def refresh(self):
        rows = self.db.list_doctors(active_only=False)
        fill_table(self.table, [(r["full_name"], r["specialty"], r["phone"], "Aktif" if r["active"] else "Pasif") for r in rows],
                   [r["id"] for r in rows], row_colors=[None if r["active"] else "#eceff1" for r in rows])

    def _new(self):
        if DoctorDialog(self.db, parent=self).exec():
            self.on_change()

    def _edit(self, *_):
        did = selected_id(self.table)
        if did and DoctorDialog(self.db, self.db.get_doctor(did), self).exec():
            self.on_change()

    def _toggle(self):
        did = selected_id(self.table)
        if did:
            self.db.set_doctor_active(did, not self.db.get_doctor(did)["active"])
            self.on_change()


# ------------------------------------------------------------------ kullanıcı sayfası
class UsersPage(QWidget):
    def __init__(self, db, user):
        super().__init__()
        self.db, self.user = db, user
        root = QVBoxLayout(self)
        self.table = make_table(["Kullanıcı adı", "Ad Soyad", "Rol", "Durum"], stretch=1)
        root.addWidget(self.table, 1)
        row = QHBoxLayout()
        new = QPushButton("Yeni Kullanıcı")
        new.setObjectName("primary")
        new.clicked.connect(self._new)
        pw = QPushButton("Şifre Sıfırla")
        pw.clicked.connect(self._password)
        toggle = QPushButton("Aktif / Pasif Yap")
        toggle.clicked.connect(self._toggle)
        for w in (new, pw, toggle):
            row.addWidget(w)
        row.addStretch(1)
        root.addLayout(row)
        self.refresh()

    def refresh(self):
        rows = self.db.list_users()
        fill_table(self.table, [(r["username"], r["full_name"], dbm.ROLES[r["role"]], "Aktif" if r["active"] else "Pasif") for r in rows],
                   [r["id"] for r in rows], row_colors=[None if r["active"] else "#eceff1" for r in rows])

    def _new(self):
        if UserDialog(self.db, self).exec():
            self.refresh()

    def _password(self):
        uid = selected_id(self.table)
        if uid:
            PasswordDialog(self.db, uid, parent=self).exec()

    def _toggle(self):
        uid = selected_id(self.table)
        if not uid:
            return
        u = next(r for r in self.db.list_users() if r["id"] == uid)
        try:
            self.db.set_user_active(uid, not u["active"])
        except ValueError as e:
            notify(self, "Yapılamadı", str(e), QMessageBox.Icon.Warning)
        self.refresh()


# ------------------------------------------------------------------ ana pencere
class MainWindow(QMainWindow):
    def __init__(self, db, user):
        super().__init__()
        self.db, self.user, self.cards = db, user, {}
        self.setWindowTitle(f"{APP_NAME} — Klinik Randevu ve Hasta Takip")
        self.setWindowIcon(app_icon())
        self.resize(1240, 800)
        admin = user["role"] == "admin"

        self.tabs = QTabWidget()
        self.setCentralWidget(self._wrap(self.tabs))
        self.p_appt = AppointmentsPage(db, user, self.open_card, self.refresh_all)
        self.p_pat = PatientsPage(db, user, self.open_card, self.refresh_all, self.close_card)
        self.tabs.addTab(self.p_appt, "Randevular")
        self.tabs.addTab(self.p_pat, "Hastalar")
        self.p_doc = self.p_usr = None
        if admin:
            self.p_doc = DoctorsPage(db, self.refresh_all)
            self.p_usr = UsersPage(db, user)
            self.tabs.addTab(self.p_doc, "Doktorlar")
            self.tabs.addTab(self.p_usr, "Kullanıcılar")

        mb = self.menuBar()
        file_menu = mb.addMenu("Dosya")
        if admin:
            file_menu.addAction("Yedek Al…", self.make_backup)
            file_menu.addAction("Yedekten Geri Yükle…", self.restore_backup)
            file_menu.addSeparator()
        file_menu.addAction("Şifremi Değiştir…", self.change_own_password)
        file_menu.addSeparator()
        file_menu.addAction("Çıkış", self.close)
        mb.addMenu("Yardım").addAction("Hakkında", self.about)
        self.statusBar().showMessage(f"Giriş yapan: {user['full_name']} ({dbm.ROLES[user['role']]})   •   "
                                     f"Veri klasörü: {db.base}")
        self.tabs.currentChanged.connect(lambda *_: self.refresh_all())

    @staticmethod
    def _wrap(w):
        box = QWidget()
        lay = QVBoxLayout(box)
        lay.setContentsMargins(12, 12, 12, 6)
        lay.addWidget(w)
        return box

    def refresh_all(self):
        self.p_appt.reload_doctors()  # doktor listesi + randevular
        self.p_pat.refresh()
        if self.p_doc:
            self.p_doc.refresh()

    def open_card(self, pid):
        c = self.cards.get(pid)
        if c:
            c.showNormal()
            c.raise_()
            c.activateWindow()
            return
        c = PatientCard(self.db, self.user, pid, self.refresh_all, self)
        self.cards[pid] = c
        c.destroyed.connect(lambda *_, p=pid: self.cards.pop(p, None))
        c.show()

    def close_card(self, pid):
        c = self.cards.get(pid)
        if c:
            c.close()

    def prompt_first_doctor(self):
        if self.user["role"] == "admin" and not self.db.list_doctors(active_only=False):
            if confirm(self, "Doktor ekleyin", "Henüz hiç doktor tanımlı değil. Randevu ve tedavi kaydı için en az bir doktor gerekir.\n\n"
                       "Şimdi doktor eklemek ister misiniz?", yes="Doktor Ekle", no="Sonra"):
                self.tabs.setCurrentWidget(self.p_doc)
                self.p_doc._new()

    def make_backup(self):
        default = os.path.join(os.path.expanduser("~"), "Documents", f"DisPlan_Yedek_{dt.date.today():%Y%m%d}.zip")
        path, _ = QFileDialog.getSaveFileName(self, "Yedeği kaydet", default, "Zip arşivi (*.zip)")
        if path:
            try:
                self.db.backup(path)
                notify(self, "Yedek alındı", f"Veritabanı ve tüm röntgenler yedeklendi:\n{path}\n\n"
                       "Bu dosyayı harici bir diske veya güvenli bir buluta da kopyalamanızı öneririz.")
            except Exception as e:
                notify(self, "Yedek alınamadı", str(e), QMessageBox.Icon.Warning)

    def restore_backup(self):
        if not confirm(self, "Yedekten geri yükle",
                       "Seçeceğiniz yedek, mevcut verilerin YERİNE geçer (mevcut veritabanı güvenlik için ayrıca saklanır).\n"
                       "İşlem sonunda uygulama kapanır; yeniden açmanız gerekir.\n\nDevam edilsin mi?", yes="Devam", no="Vazgeç"):
            return
        path, _ = QFileDialog.getOpenFileName(self, "Yedek dosyasını seçin", "", "Zip arşivi (*.zip)")
        if not path:
            return
        try:
            self.db.restore(path)
        except Exception as e:
            notify(self, "Geri yüklenemedi", str(e), QMessageBox.Icon.Warning)
            return
        notify(self, "Geri yüklendi", "Yedek geri yüklendi. Uygulama şimdi kapanacak; lütfen yeniden açın.")
        QApplication.quit()

    def change_own_password(self):
        PasswordDialog(self.db, self.user["id"], self.user["username"], self).exec()

    def about(self):
        notify(self, f"{APP_NAME} Hakkında",
               f"<b>{APP_NAME}</b> — özel diş klinikleri için randevu ve hasta takip uygulaması<br><br>"
               f"Veri klasörü:<br><code>{self.db.base}</code><br><br>"
               "Hasta kayıtları sağlık verisi niteliğindedir (KVKK kapsamında özel nitelikli kişisel veri). "
               "Bilgisayarın disk şifrelemesini (BitLocker) açmanız ve düzenli yedek almanız önerilir.")

    def closeEvent(self, e):
        for c in list(self.cards.values()):
            c.close()
        self.db.close()
        super().closeEvent(e)


def _install_excepthook():
    def hook(exc_type, exc, tb):
        text = "".join(traceback.format_exception(exc_type, exc, tb))
        try:
            with open(os.path.join(dbm.data_dir(), "hata.log"), "a", encoding="utf-8") as f:
                f.write(f"\n--- {dt.datetime.now():%Y-%m-%d %H:%M:%S}\n{text}")
        except OSError:
            pass
        print(text, file=sys.stderr)
        if QApplication.instance():
            box = QMessageBox(QMessageBox.Icon.Critical, "Beklenmeyen hata",
                              "Bir hata oluştu. Verileriniz korunmuştur.\nAyrıntılar veri klasöründeki hata.log dosyasındadır.")
            box.setDetailedText(text)
            box.addButton("Tamam", QMessageBox.ButtonRole.AcceptRole)
            box.exec()
    sys.excepthook = hook


def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setStyle("Fusion")
    app.setFont(QFont("Segoe UI", 10))
    app.setStyleSheet(STYLE)
    app.setWindowIcon(app_icon())
    tr = QTranslator()
    if tr.load("qtbase_tr", QLibraryInfo.path(QLibraryInfo.LibraryPath.TranslationsPath)):
        app.installTranslator(tr)
    _install_excepthook()

    db = dbm.DB()
    try:
        db.auto_backup()
    except Exception:
        pass
    if db.user_count() == 0:
        setup = SetupDialog(db)
        if not setup.exec():
            return 0
        user = db.authenticate(setup.f_user.text(), setup.f_pass.text())
    else:
        login = LoginDialog(db)
        if not login.exec():
            return 0
        user = login.user
    win = MainWindow(db, user)
    win.show()
    QTimer.singleShot(400, win.prompt_first_doctor)
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
