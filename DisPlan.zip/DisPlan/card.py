"""DişPlan - hasta kartı penceresi."""
import html

from PySide6.QtCore import QSize, Qt
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel,
                               QListView, QListWidget, QListWidgetItem, QPushButton, QTabWidget,
                               QVBoxLayout, QWidget)

import db as dbm
from dialogs import AppointmentDialog, PatientForm, TreatmentDialog, XrayDialog
from widgets import (Odontogram, XrayViewer, confirm, fill_table, legend_widget, make_table, money,
                     selected_id, thumb_icon, tooth_name)

STATUS_COLORS = {"Geldi": "#fff8e1", "Tamamlandı": "#e8f5e9", "İptal": "#eceff1", "Gelmedi": "#ffebee"}


def esc(s):
    return html.escape(s or "")


class PatientCard(QDialog):
    def __init__(self, db, user, pid, on_change, parent=None):
        super().__init__(parent)
        self.db, self.user, self.pid, self.on_change = db, user, pid, on_change
        self.can_edit = user["role"] in ("admin", "doktor")
        self.sel_tooth = None
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)
        self.setWindowFlag(Qt.WindowType.WindowMinimizeButtonHint, True)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.resize(1160, 800)

        root = QVBoxLayout(self)
        root.addWidget(self._build_header())
        self.tabs = QTabWidget()
        root.addWidget(self.tabs, 1)
        self._build_info_tab()
        self._build_teeth_tab()
        self._build_treat_tab()
        self._build_xray_tab()
        self._build_appt_tab()
        self.refresh_all()

    # ---------------------------------------------------------------- başlık
    def _build_header(self):
        frame = QFrame()
        frame.setObjectName("cardHeader")
        lay = QVBoxLayout(frame)
        self.h_name = QLabel()
        self.h_name.setObjectName("cardName")
        self.h_sub = QLabel()
        self.h_sub.setStyleSheet("color:#546e7a")
        self.h_alert = QLabel()
        self.h_alert.setTextFormat(Qt.TextFormat.RichText)
        self.h_alert.setWordWrap(True)
        self.h_alert.setObjectName("alertBox")
        lay.addWidget(self.h_name)
        lay.addWidget(self.h_sub)
        lay.addWidget(self.h_alert)
        grid = QHBoxLayout()
        self.stat = {}
        for key, caption in (("last", "SON YAPILAN İŞLEM"), ("doctor", "SON BAKAN DOKTOR"),
                             ("next", "SONRAKİ RANDEVU"), ("balance", "KALAN BORÇ"), ("xray", "RÖNTGEN")):
            box = QFrame()
            box.setObjectName("statBox")
            bl = QVBoxLayout(box)
            bl.setContentsMargins(12, 8, 12, 8)
            cap = QLabel(caption)
            cap.setObjectName("statCap")
            val = QLabel()
            val.setTextFormat(Qt.TextFormat.RichText)
            val.setWordWrap(True)
            bl.addWidget(cap)
            bl.addWidget(val)
            self.stat[key] = val
            grid.addWidget(box, 2 if key in ("last", "doctor", "next") else 1)
        lay.addLayout(grid)
        return frame

    def refresh_header(self):
        p = self.db.get_patient(self.pid)
        s = self.db.patient_summary(self.pid)
        self.setWindowTitle(f"Hasta Kartı — {p['full_name']}")
        self.h_name.setText(p["full_name"])
        age = dbm.age_from(p["birth_date"])
        bits = [f"{age} yaşında" if age is not None else "", p["gender"] if p["gender"] != "Belirtilmemiş" else "",
                f"Tel: {p['phone']}" if p["phone"] else "", f"TC: {p['tc_no']}" if p["tc_no"] else "",
                f"Kan grubu: {p['blood_type']}" if p["blood_type"] else ""]
        self.h_sub.setText("   •   ".join(b for b in bits if b))
        alerts = []
        for label, key in (("Alerji", "allergies"), ("Kronik hastalık", "chronic_diseases"), ("İlaç", "medications")):
            if p[key].strip():
                alerts.append(f"<b>{label}:</b> {esc(p[key].strip()).replace(chr(10), ', ')}")
        self.h_alert.setText("⚠&nbsp;&nbsp;" + "&nbsp;&nbsp;&nbsp;•&nbsp;&nbsp;&nbsp;".join(alerts) if alerts else "")
        self.h_alert.setVisible(bool(alerts))

        last = s["last"]
        if last:
            tooth = f" <span style='color:#546e7a'>(diş {esc(last['tooth_no'])})</span>" if last["tooth_no"] else ""
            who = f" • {esc(last['doctor'])}" if last["doctor"] else ""
            self.stat["last"].setText(f"<b>{esc(last['procedure'])}</b>{tooth}<br>"
                                      f"<span style='color:#78909c'>{dbm.fmt_date(last['date'])}{who}</span>")
        else:
            self.stat["last"].setText("<span style='color:#90a4ae'>Henüz işlem kaydı yok</span>")
        if s["doctor"]:
            self.stat["doctor"].setText(f"<b>{esc(s['doctor'])}</b><br>"
                                        f"<span style='color:#78909c'>son ziyaret: {dbm.fmt_date(s['last_visit'])}</span>")
        else:
            self.stat["doctor"].setText("<span style='color:#90a4ae'>—</span>")
        n = s["next"]
        if n:
            detail = " • ".join(x for x in (n["doctor"], n["procedure"]) if x)
            self.stat["next"].setText(f"<b>{dbm.fmt_date(n['date'])} {n['time']}</b><br>"
                                      f"<span style='color:#78909c'>{esc(detail)}</span>")
        else:
            self.stat["next"].setText("<span style='color:#90a4ae'>Planlı randevu yok</span>")
        color = "#c62828" if s["balance"] > 0.005 else "#2e7d32"
        self.stat["balance"].setText(f"<b style='color:{color}'>{money(s['balance'])}</b>")
        self.stat["xray"].setText(f"<b>{s['xray_count']}</b> adet")

    # ---------------------------------------------------------------- genel bilgiler
    def _build_info_tab(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        self.pform = PatientForm(self.db, self.db.get_patient(self.pid))
        lay.addWidget(self.pform)
        row = QHBoxLayout()
        self.info_msg = QLabel()
        self.info_msg.setStyleSheet("color:#c62828;font-weight:600")
        row.addWidget(self.info_msg, 1)
        revert = QPushButton("Değişiklikleri Geri Al")
        revert.clicked.connect(lambda: self.pform.load(self.db.get_patient(self.pid)))
        save = QPushButton("Bilgileri Kaydet")
        save.setObjectName("primary")
        save.clicked.connect(self._save_info)
        row.addWidget(revert)
        row.addWidget(save)
        lay.addLayout(row)
        lay.addStretch(1)
        self.tabs.addTab(page, "Genel Bilgiler")

    def _save_info(self):
        try:
            self.pform.save(self.pid)
        except ValueError as e:
            self.info_msg.setText(str(e))
            return
        self.info_msg.setText("")
        self._changed()

    # ---------------------------------------------------------------- diş şeması
    def _build_teeth_tab(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        top = QHBoxLayout()
        hint = QLabel("Bir dişe tıklayın: durumunu değiştirin ve o dişe yapılan işlemleri görün.")
        hint.setStyleSheet("color:#607d8b")
        top.addWidget(hint, 1)
        self.chk_decid = QCheckBox("Süt dişlerini göster")
        self.chk_decid.toggled.connect(self._toggle_decid)
        top.addWidget(self.chk_decid)
        lay.addLayout(top)
        self.odo = Odontogram()
        self.odo.toothClicked.connect(self._on_tooth)
        lay.addWidget(self.odo)
        lay.addWidget(legend_widget())

        panel = QFrame()
        panel.setObjectName("statBox")
        pl = QVBoxLayout(panel)
        head = QHBoxLayout()
        self.lbl_tooth = QLabel("Dişi seçin")
        self.lbl_tooth.setStyleSheet("font-size:15px;font-weight:700")
        head.addWidget(self.lbl_tooth, 1)
        head.addWidget(QLabel("Durum:"))
        self.cb_status = QComboBox()
        self.cb_status.addItems(dbm.TOOTH_STATUSES)
        self.cb_status.activated.connect(self._set_tooth_status)
        head.addWidget(self.cb_status)
        self.btn_tooth_treat = QPushButton("Bu dişe işlem ekle")
        self.btn_tooth_treat.clicked.connect(self._add_for_tooth)
        head.addWidget(self.btn_tooth_treat)
        pl.addLayout(head)
        self.tooth_table = make_table(["Tarih", "İşlem", "Doktor", "Not"], stretch=3)
        pl.addWidget(self.tooth_table)
        lay.addWidget(panel, 1)
        for w in (self.cb_status, self.btn_tooth_treat):
            w.setEnabled(False)
        self.tabs.addTab(page, "Diş Şeması")

    def _toggle_decid(self, on):
        self.odo.set_deciduous(on)

    def _on_tooth(self, t):
        self.sel_tooth = t
        self.lbl_tooth.setText(f"Diş {t} — {tooth_name(t)}")
        st = self.db.get_tooth_status(self.pid).get(t, dbm.DEFAULT_TOOTH_STATUS)
        self.cb_status.setCurrentText(st)
        for w in (self.cb_status, self.btn_tooth_treat):
            w.setEnabled(self.can_edit)
        rows = self.db.treatments_for_tooth(self.pid, t)
        fill_table(self.tooth_table, [(dbm.fmt_date(r["date"]), r["procedure"], r["doctor"] or "—", r["notes"])
                                      for r in rows], [r["id"] for r in rows])

    def _set_tooth_status(self, _):
        if self.sel_tooth:
            self.db.set_tooth_status(self.pid, self.sel_tooth, self.cb_status.currentText())
            self.odo.set_data(self.db.get_tooth_status(self.pid))

    def _add_for_tooth(self):
        if self.sel_tooth:
            self._treatment_dialog(defaults={"tooth_no": str(self.sel_tooth), "procedure": "Dolgu"})

    # ---------------------------------------------------------------- tedaviler
    def _build_treat_tab(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        self.t_table = make_table(["Tarih", "Diş", "İşlem", "Doktor", "Ücret", "Ödenen", "Kalan", "Not"], stretch=7)
        self.t_table.doubleClicked.connect(self._edit_treatment)
        lay.addWidget(self.t_table, 1)
        row = QHBoxLayout()
        self.t_total = QLabel()
        row.addWidget(self.t_total, 1)
        self.btn_t_add = QPushButton("Yeni İşlem Ekle")
        self.btn_t_add.setObjectName("primary")
        self.btn_t_add.clicked.connect(lambda: self._treatment_dialog())
        self.btn_t_edit = QPushButton("Düzenle")
        self.btn_t_edit.clicked.connect(self._edit_treatment)
        self.btn_t_del = QPushButton("Sil")
        self.btn_t_del.clicked.connect(self._delete_treatment)
        for b in (self.btn_t_add, self.btn_t_edit, self.btn_t_del):
            row.addWidget(b)
            b.setEnabled(self.can_edit)
        lay.addLayout(row)
        if not self.can_edit:
            note = QLabel("Bu bölümü yalnızca doktor ve yönetici düzenleyebilir.")
            note.setStyleSheet("color:#78909c")
            lay.addWidget(note)
        self.tabs.addTab(page, "Tedaviler")

    def _treatment_dialog(self, treat=None, defaults=None):
        dlg = TreatmentDialog(self.db, self.pid, treat, defaults, self)
        if dlg.exec():
            self._changed()

    def _edit_treatment(self, *_):
        tid = selected_id(self.t_table)
        if tid and self.can_edit:
            self._treatment_dialog(self.db.get_treatment(tid))

    def _delete_treatment(self):
        tid = selected_id(self.t_table)
        if tid and confirm(self, "İşlemi sil", "Seçili işlem kaydı silinsin mi?\n(Diş şemasındaki durum otomatik geri alınmaz.)",
                           yes="Sil", no="Vazgeç"):
            self.db.delete_treatment(tid)
            self._changed()

    def refresh_treatments(self):
        rows = self.db.list_treatments(self.pid)
        fill_table(self.t_table,
                   [(dbm.fmt_date(r["date"]), r["tooth_no"], r["procedure"], r["doctor"] or "—", money(r["fee"]),
                     money(r["paid"]), money(r["fee"] - r["paid"]), r["notes"]) for r in rows],
                   [r["id"] for r in rows], right_cols=(4, 5, 6))
        fee, paid = sum(r["fee"] for r in rows), sum(r["paid"] for r in rows)
        self.t_total.setText(f"<b>{len(rows)}</b> işlem   •   Toplam: <b>{money(fee)}</b>   •   Ödenen: <b>{money(paid)}</b>"
                             f"   •   Kalan: <b style='color:{'#c62828' if fee - paid > 0.005 else '#2e7d32'}'>{money(fee - paid)}</b>")

    # ---------------------------------------------------------------- röntgenler
    def _build_xray_tab(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        self.x_list = QListWidget()
        self.x_list.setViewMode(QListView.ViewMode.IconMode)
        self.x_list.setIconSize(QSize(210, 150))
        self.x_list.setGridSize(QSize(240, 215))
        self.x_list.setResizeMode(QListView.ResizeMode.Adjust)
        self.x_list.setMovement(QListView.Movement.Static)
        self.x_list.setWordWrap(True)
        self.x_list.setUniformItemSizes(True)
        self.x_list.itemDoubleClicked.connect(lambda *_: self._view_xray())
        self.x_list.currentItemChanged.connect(lambda *_: self._show_xray_info())
        lay.addWidget(self.x_list, 1)
        self.x_info = QLabel()
        self.x_info.setTextFormat(Qt.TextFormat.RichText)
        self.x_info.setWordWrap(True)
        self.x_info.setObjectName("statBox")
        self.x_info.setMinimumHeight(64)
        lay.addWidget(self.x_info)
        row = QHBoxLayout()
        row.addStretch(1)
        self.btn_x_add = QPushButton("Röntgen Ekle…")
        self.btn_x_add.setObjectName("primary")
        self.btn_x_add.clicked.connect(self._add_xray)
        b_view = QPushButton("Görüntüle")
        b_view.clicked.connect(self._view_xray)
        self.btn_x_edit = QPushButton("Bilgileri Düzenle")
        self.btn_x_edit.clicked.connect(self._edit_xray)
        self.btn_x_del = QPushButton("Sil")
        self.btn_x_del.clicked.connect(self._delete_xray)
        for b in (self.btn_x_add, b_view, self.btn_x_edit, self.btn_x_del):
            row.addWidget(b)
        for b in (self.btn_x_add, self.btn_x_edit, self.btn_x_del):
            b.setEnabled(self.can_edit)
        lay.addLayout(row)
        self.tabs.addTab(page, "Röntgenler")

    def _current_xray(self):
        it = self.x_list.currentItem()
        return self.db.get_xray(it.data(Qt.ItemDataRole.UserRole)) if it else None

    def _show_xray_info(self):
        x = self._current_xray()
        if not x:
            self.x_info.setText("<span style='color:#90a4ae'>Ayrıntı için bir röntgen seçin; büyütmek için çift tıklayın.</span>")
            return
        doc = self.db.get_doctor(x["doctor_id"]) if x["doctor_id"] else None
        self.x_info.setText(self._xray_html(x, doc))

    @staticmethod
    def _xray_html(x, doc):
        parts = [f"<b>{esc(x['kind'] or 'Röntgen')}</b> — {dbm.fmt_date(x['date'])}"]
        parts.append(f"Doktor: <b>{esc(doc['full_name']) if doc else '—'}</b>")
        if x["tooth_no"]:
            parts.append(f"Diş: <b>{esc(x['tooth_no'])}</b>")
        s = "   •   ".join(parts)
        if x["notes"]:
            s += f"<br>Bulgu / not: {esc(x['notes'])}"
        return s

    def refresh_xrays(self):
        keep = self.x_list.currentItem().data(Qt.ItemDataRole.UserRole) if self.x_list.currentItem() else None
        self.x_list.clear()
        for x in self.db.list_xrays(self.pid):
            label = f"{x['kind'] or 'Röntgen'}\n{dbm.fmt_date(x['date'])}"
            if x["doctor"]:
                label += f"\n{x['doctor']}"
            it = QListWidgetItem(thumb_icon(self.db.xray_abs_path(x["file_path"])), label)
            it.setData(Qt.ItemDataRole.UserRole, x["id"])
            it.setTextAlignment(Qt.AlignmentFlag.AlignHCenter)
            self.x_list.addItem(it)
            if x["id"] == keep:
                self.x_list.setCurrentItem(it)
        self._show_xray_info()

    def _add_xray(self):
        dlg = XrayDialog(self.db, self.pid, parent=self)
        if dlg.exec():
            self._changed()

    def _edit_xray(self):
        x = self._current_xray()
        if x and XrayDialog(self.db, self.pid, x, self).exec():
            self._changed()

    def _view_xray(self):
        x = self._current_xray()
        if not x:
            return
        doc = self.db.get_doctor(x["doctor_id"]) if x["doctor_id"] else None
        p = self.db.get_patient(self.pid)
        XrayViewer(self.db.xray_abs_path(x["file_path"]), f"{x['kind'] or 'Röntgen'} — {p['full_name']}",
                   self._xray_html(x, doc), self).exec()

    def _delete_xray(self):
        x = self._current_xray()
        if x and confirm(self, "Röntgeni sil", "Seçili röntgen kaydı ve dosyası kalıcı olarak silinsin mi?",
                         yes="Sil", no="Vazgeç"):
            self.db.delete_xray(x["id"])
            self._changed()

    # ---------------------------------------------------------------- randevular
    def _build_appt_tab(self):
        page = QWidget()
        lay = QVBoxLayout(page)
        self.a_table = make_table(["Tarih", "Saat", "Doktor", "İşlem", "Durum", "Not"], stretch=5)
        self.a_table.doubleClicked.connect(self._edit_appt)
        lay.addWidget(self.a_table, 1)
        row = QHBoxLayout()
        row.addStretch(1)
        b_new = QPushButton("Yeni Randevu")
        b_new.setObjectName("primary")
        b_new.clicked.connect(self._new_appt)
        b_edit = QPushButton("Düzenle")
        b_edit.clicked.connect(self._edit_appt)
        b_del = QPushButton("Sil")
        b_del.clicked.connect(self._delete_appt)
        for b in (b_new, b_edit, b_del):
            row.addWidget(b)
        lay.addLayout(row)
        self.tabs.addTab(page, "Randevular")

    def refresh_appts(self):
        rows = self.db.patient_appointments(self.pid)
        fill_table(self.a_table, [(dbm.fmt_date(r["date"]), r["time"], r["doctor"] or "—", r["procedure"],
                                   r["status"], r["notes"]) for r in rows], [r["id"] for r in rows],
                   row_colors=[STATUS_COLORS.get(r["status"]) for r in rows])

    def _new_appt(self):
        if AppointmentDialog(self.db, patient_id=self.pid, doctor_id=self.db.default_doctor_id(self.pid), parent=self).exec():
            self._changed()

    def _edit_appt(self, *_):
        aid = selected_id(self.a_table)
        if aid and AppointmentDialog(self.db, appt=self.db.get_appointment(aid), parent=self).exec():
            self._changed()

    def _delete_appt(self):
        aid = selected_id(self.a_table)
        if aid and confirm(self, "Randevuyu sil", "Seçili randevu silinsin mi?", yes="Sil", no="Vazgeç"):
            self.db.delete_appointment(aid)
            self._changed()

    # ---------------------------------------------------------------- ortak
    def refresh_all(self):
        self.refresh_header()
        self.odo.set_data(self.db.get_tooth_status(self.pid))
        if self.sel_tooth:
            self._on_tooth(self.sel_tooth)
        self.refresh_treatments()
        self.refresh_xrays()
        self.refresh_appts()

    def _changed(self):
        self.refresh_all()
        self.on_change()
