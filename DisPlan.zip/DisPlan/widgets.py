"""DişPlan - ortak arayüz bileşenleri: tablo yardımcıları, diş şeması, röntgen görüntüleyici."""
import os

from PIL import Image, ImageEnhance, ImageOps
from PySide6.QtCore import QDate, QRectF, QSize, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import (QColor, QDesktopServices, QFont, QIcon, QImage, QPainter, QPainterPath,
                           QPen, QPixmap)
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QDialog, QGraphicsScene,
                               QGraphicsView, QHBoxLayout, QHeaderView, QLabel, QMessageBox,
                               QPushButton, QSlider, QTableWidget, QTableWidgetItem, QToolTip,
                               QVBoxLayout, QWidget)

import db as dbm

UR = Qt.ItemDataRole.UserRole


# ------------------------------------------------------------------ genel yardımcılar
def money(v):
    s = f"{float(v or 0):,.2f}"
    return s.replace(",", "§").replace(".", ",").replace("§", ".") + " ₺"


def qdate_iso(qd):
    return qd.toString("yyyy-MM-dd")


def iso_qdate(iso):
    qd = QDate.fromString(iso or "", "yyyy-MM-dd")
    return qd if qd.isValid() else QDate.currentDate()


def confirm(parent, title, text, yes="Evet", no="Hayır"):
    box = QMessageBox(QMessageBox.Icon.Question, title, text, parent=parent)
    b_yes = box.addButton(yes, QMessageBox.ButtonRole.AcceptRole)
    b_no = box.addButton(no, QMessageBox.ButtonRole.RejectRole)
    box.setDefaultButton(b_no)
    box.exec()
    return box.clickedButton() is b_yes


def notify(parent, title, text, icon=QMessageBox.Icon.Information):
    box = QMessageBox(icon, title, text, parent=parent)
    box.addButton("Tamam", QMessageBox.ButtonRole.AcceptRole)
    box.exec()


def make_table(headers, stretch=None):
    t = QTableWidget(0, len(headers))
    t.setHorizontalHeaderLabels(headers)
    t.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    t.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
    t.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    t.verticalHeader().setVisible(False)
    t.verticalHeader().setDefaultSectionSize(30)
    t.setAlternatingRowColors(True)
    t.setShowGrid(False)
    t.setWordWrap(False)
    h = t.horizontalHeader()
    h.setHighlightSections(False)
    for i in range(len(headers)):
        mode = QHeaderView.ResizeMode.Stretch if i == stretch else QHeaderView.ResizeMode.ResizeToContents
        h.setSectionResizeMode(i, mode)
    return t


def selected_id(t):
    r = t.currentRow()
    if r < 0 or not t.item(r, 0):
        return None
    return t.item(r, 0).data(UR)


def fill_table(t, rows, ids, row_colors=None, right_cols=()):
    prev = selected_id(t)
    t.setRowCount(len(rows))
    for r, vals in enumerate(rows):
        for c, v in enumerate(vals):
            it = QTableWidgetItem("" if v is None else str(v))
            if c == 0:
                it.setData(UR, ids[r])
            if c in right_cols:
                it.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            if row_colors and row_colors[r]:
                it.setBackground(QColor(row_colors[r]))
            t.setItem(r, c, it)
    if prev is not None:
        for r in range(t.rowCount()):
            if t.item(r, 0).data(UR) == prev:
                t.selectRow(r)
                break


def doctor_combo(db, selected=None, allow_none=False):
    cb = QComboBox()
    if allow_none:
        cb.addItem("Tüm doktorlar", None)
    present = set()
    for d in db.list_doctors():
        label = d["full_name"] + (f"  ({d['specialty']})" if d["specialty"] else "")
        cb.addItem(label, d["id"])
        present.add(d["id"])
    if selected and selected not in present:
        d = db.get_doctor(selected)
        if d:
            cb.addItem(d["full_name"] + "  (pasif)", d["id"])
    if selected:
        idx = cb.findData(selected)
        if idx >= 0:
            cb.setCurrentIndex(idx)
    return cb


_POS = {1: "Santral kesici", 2: "Lateral kesici", 3: "Kanin (köpek)", 4: "1. Premolar",
        5: "2. Premolar", 6: "1. Molar", 7: "2. Molar", 8: "3. Molar (yirmilik)"}
_POS_D = {1: "Santral kesici", 2: "Lateral kesici", 3: "Kanin (köpek)", 4: "1. Süt molar", 5: "2. Süt molar"}
_QUAD = {1: "Sağ üst", 2: "Sol üst", 3: "Sol alt", 4: "Sağ alt",
         5: "Sağ üst süt", 6: "Sol üst süt", 7: "Sol alt süt", 8: "Sağ alt süt"}


def tooth_name(t):
    q, n = divmod(t, 10)
    pos = (_POS_D if q >= 5 else _POS).get(n, "")
    return f"{_QUAD.get(q, '')} {pos}".strip()


# ------------------------------------------------------------------ diş şeması
STATUS_STYLE = {
    "Sağlam": ("#ffffff", ""),
    "Çürük": ("#ef9a9a", "Ç"),
    "Dolgu": ("#90caf9", "D"),
    "Kanal Tedavisi": ("#ce93d8", "K"),
    "Kaplama / Kron": ("#ffe082", "Kr"),
    "İmplant": ("#b0bec5", "İ"),
    "Çekilmiş / Eksik": ("#eceff1", "✕"),
    "Planlanan Tedavi": ("#ffcc80", "P"),
}


class Odontogram(QWidget):
    """FDI numaralamalı diş şeması. Dişe tıklanınca toothClicked(diş_no) yayar."""
    toothClicked = Signal(int)

    UPPER = [18, 17, 16, 15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 26, 27, 28]
    LOWER = [48, 47, 46, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35, 36, 37, 38]
    UPPER_D = [55, 54, 53, 52, 51, 61, 62, 63, 64, 65]
    LOWER_D = [85, 84, 83, 82, 81, 71, 72, 73, 74, 75]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.status = {}
        self.selected = None
        self.show_deciduous = False
        self._rects = {}
        self._midx = 0
        self._midy = 0
        self.setMouseTracking(True)
        self.setMinimumSize(660, 250)

    def set_data(self, status):
        self.status = dict(status)
        self.update()

    def set_selected(self, tooth):
        self.selected = tooth
        self.update()

    def set_deciduous(self, on):
        self.show_deciduous = on
        self.setMinimumHeight(400 if on else 250)
        self.update()

    def sizeHint(self):
        return QSize(900, 400 if self.show_deciduous else 270)

    def _layout(self):
        self._rects.clear()
        rows = [self.UPPER]
        upper_end = 0
        if self.show_deciduous:
            rows += [self.UPPER_D, self.LOWER_D]
            upper_end = 1
        rows.append(self.LOWER)
        W, H = self.width(), self.height()
        gap = 20
        tw = min(48.0, (W - 40 - gap) / 16)
        th = tw * 1.3
        row_h = th + 26
        y0 = max(22.0, (H - row_h * len(rows)) / 2 + 6)
        for ri, row in enumerate(rows):
            n = len(row)
            half = n // 2
            x0 = (W - (n * tw + gap)) / 2
            y = y0 + ri * row_h
            for i, t in enumerate(row):
                x = x0 + i * tw + (gap if i >= half else 0)
                self._rects[t] = QRectF(x + 2, y, tw - 4, th)
        self._midx = W / 2
        self._midy = y0 + (upper_end + 1) * row_h - 8
        self._tw = tw

    def _tooth_at(self, pos):
        self._layout()
        for t, r in self._rects.items():
            if r.adjusted(-2, -2, 2, 16).contains(pos):
                return t
        return None

    def mousePressEvent(self, e):
        t = self._tooth_at(e.position())
        if t:
            self.selected = t
            self.update()
            self.toothClicked.emit(t)

    def mouseMoveEvent(self, e):
        t = self._tooth_at(e.position())
        if t:
            self.setCursor(Qt.CursorShape.PointingHandCursor)
            QToolTip.showText(e.globalPosition().toPoint(),
                              f"Diş {t} — {tooth_name(t)}\n{self.status.get(t, 'Sağlam')}", self)
        else:
            self.unsetCursor()
            QToolTip.hideText()

    def paintEvent(self, _):
        self._layout()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor("#fafbfc"))
        p.setPen(QPen(QColor("#cfd8dc"), 1, Qt.PenStyle.DashLine))
        p.drawLine(int(self._midx), 24, int(self._midx), self.height() - 12)
        p.drawLine(24, int(self._midy), self.width() - 24, int(self._midy))
        f = QFont(self.font())
        f.setPixelSize(11)
        p.setFont(f)
        p.setPen(QColor("#90a4ae"))
        p.drawText(10, 16, "SAĞ")
        p.drawText(self.width() - 36, 16, "SOL")
        mark_font = QFont(self.font())
        mark_font.setBold(True)
        mark_font.setPixelSize(max(9, int(self._tw * 0.3)))
        for t, r in self._rects.items():
            st = self.status.get(t, "Sağlam")
            fill, mark = STATUS_STYLE.get(st, STATUS_STYLE["Sağlam"])
            path = QPainterPath()
            path.addRoundedRect(r, r.width() * 0.32, r.width() * 0.32)
            pen = QPen(QColor("#546e7a"), 1.4)
            if t == self.selected:
                pen = QPen(QColor("#00897b"), 3.2)
            if st == "Planlanan Tedavi":
                pen.setStyle(Qt.PenStyle.DashLine)
            p.setPen(pen)
            p.setBrush(QColor(fill))
            p.drawPath(path)
            if mark:
                p.setFont(mark_font)
                p.setPen(QColor("#37474f"))
                p.drawText(r, Qt.AlignmentFlag.AlignCenter, mark)
            p.setFont(f)
            p.setPen(QColor("#00695c") if t == self.selected else QColor("#455a64"))
            p.drawText(QRectF(r.left() - 4, r.bottom() + 3, r.width() + 8, 14),
                       Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop, str(t))


def legend_widget():
    box = QWidget()
    lay = QHBoxLayout(box)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(14)
    for name in dbm.TOOTH_STATUSES:
        fill, mark = STATUS_STYLE[name]
        chip = QLabel(mark or " ")
        chip.setFixedSize(22, 22)
        chip.setAlignment(Qt.AlignmentFlag.AlignCenter)
        dash = "dashed" if name == "Planlanan Tedavi" else "solid"
        chip.setStyleSheet(f"background:{fill};border:1.5px {dash} #546e7a;border-radius:6px;"
                           "font-weight:bold;font-size:10px;color:#37474f;")
        lay.addWidget(chip)
        lay.addWidget(QLabel(name))
    lay.addStretch(1)
    return box


# ------------------------------------------------------------------ röntgen
def load_image(path):
    """Dosyayı 8-bit RGB PIL görüntüsü olarak açar; açılamazsa None."""
    try:
        im = Image.open(path)
        im.load()
        if im.mode in ("I;16", "I;16L", "I;16B", "I"):
            im = im.point(lambda v: v * (1 / 256)).convert("L")
        return im.convert("RGB")
    except Exception:
        return None


def pil_to_pixmap(im):
    im = im.convert("RGBA")
    data = im.tobytes("raw", "RGBA")
    qimg = QImage(data, im.width, im.height, im.width * 4, QImage.Format.Format_RGBA8888)
    return QPixmap.fromImage(qimg.copy())


def thumb_icon(path, size=(210, 150)):
    im = load_image(path)
    if im is None:
        pm = QPixmap(size[0], size[1])
        pm.fill(QColor("#eceff1"))
        p = QPainter(pm)
        p.setPen(QColor("#607d8b"))
        p.drawText(pm.rect(), Qt.AlignmentFlag.AlignCenter,
                   os.path.splitext(path)[1].upper().lstrip(".") + " dosyası")
        p.end()
        return QIcon(pm)
    im.thumbnail(size)
    return QIcon(pil_to_pixmap(im))


class _ZoomView(QGraphicsView):
    def __init__(self):
        scene = QGraphicsScene()
        super().__init__(scene)
        self._scene = scene  # referansı tut; aksi halde Python sahneyi çöpe atar
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
        self.setRenderHints(QPainter.RenderHint.SmoothPixmapTransform | QPainter.RenderHint.Antialiasing)
        self.setBackgroundBrush(QColor("#101214"))
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setFrameShape(QGraphicsView.Shape.NoFrame)
        self.item = None
        self.autofit = True  # kullanıcı elle yakınlaştırana kadar pencereye sığdır

    def set_pixmap(self, pm):
        first = self.item is None
        if first:
            self.item = self.scene().addPixmap(pm)
        else:
            self.item.setPixmap(pm)
        self.scene().setSceneRect(self.item.boundingRect())
        if first:
            self.fit()

    def zoom(self, factor):
        self.autofit = False
        self.scale(factor, factor)

    def fit(self):
        if self.item is not None:
            self.autofit = True
            self.resetTransform()
            self.fitInView(self.item, Qt.AspectRatioMode.KeepAspectRatio)

    def actual(self):
        self.autofit = False
        self.resetTransform()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if self.autofit and self.item is not None:
            self.fitInView(self.item, Qt.AspectRatioMode.KeepAspectRatio)

    def wheelEvent(self, e):
        self.zoom(1.15 if e.angleDelta().y() > 0 else 1 / 1.15)


class XrayViewer(QDialog):
    """Yakınlaştırma, parlaklık/kontrast ve negatif görünümlü röntgen görüntüleyici."""

    def __init__(self, path, title, info_html, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)
        self.resize(1100, 760)
        self.path = path
        self.base = load_image(path)

        root = QVBoxLayout(self)
        info = QLabel(info_html)
        info.setTextFormat(Qt.TextFormat.RichText)
        info.setWordWrap(True)
        root.addWidget(info)

        bar = QHBoxLayout()
        self.view = _ZoomView()
        for text, fn in (("Yakınlaştır +", lambda: self.view.zoom(1.25)),
                         ("Uzaklaştır −", lambda: self.view.zoom(1 / 1.25)),
                         ("Ekrana Sığdır", self.view.fit), ("%100", self.view.actual)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            bar.addWidget(b)
        bar.addSpacing(16)
        self.s_bright = self._slider("Parlaklık", bar)
        self.s_contrast = self._slider("Kontrast", bar)
        self.c_invert = QCheckBox("Negatif")
        self.c_invert.toggled.connect(self._schedule)
        bar.addWidget(self.c_invert)
        reset = QPushButton("Sıfırla")
        reset.clicked.connect(self._reset)
        bar.addWidget(reset)
        bar.addStretch(1)
        ext = QPushButton("Harici programda aç")
        ext.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(self.path)))
        bar.addWidget(ext)
        root.addLayout(bar)
        root.addWidget(self.view, 1)
        hint = QLabel("İpucu: fare tekerleği yakınlaştırır, basılı tutup sürükleyerek görüntüyü kaydırabilirsiniz.")
        hint.setStyleSheet("color:#78909c")
        root.addWidget(hint)

        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(90)
        self._timer.timeout.connect(self._apply)
        if self.base is None:
            msg = QLabel("Bu dosya türü uygulamada önizlenemiyor (ör. DICOM). "
                         "“Harici programda aç” düğmesini kullanın.")
            msg.setAlignment(Qt.AlignmentFlag.AlignCenter)
            root.insertWidget(2, msg)
            self.view.hide()
            for w in (self.s_bright, self.s_contrast, self.c_invert):
                w.setEnabled(False)
        else:
            self._apply()

    def _slider(self, name, bar):
        bar.addWidget(QLabel(name))
        s = QSlider(Qt.Orientation.Horizontal)
        s.setRange(-100, 100)
        s.setValue(0)
        s.setFixedWidth(120)
        s.valueChanged.connect(self._schedule)
        bar.addWidget(s)
        return s

    def _schedule(self, *_):
        self._timer.start()

    def _reset(self):
        for s in (self.s_bright, self.s_contrast):
            s.setValue(0)
        self.c_invert.setChecked(False)

    def _apply(self):
        im = self.base
        b, c = self.s_bright.value(), self.s_contrast.value()
        if b:
            im = ImageEnhance.Brightness(im).enhance(1 + b / 100)
        if c:
            im = ImageEnhance.Contrast(im).enhance(1 + c / 60)
        if self.c_invert.isChecked():
            im = ImageOps.invert(im)
        self.view.set_pixmap(pil_to_pixmap(im))
