"""DişPlan - iletişim kutuları."""
import os

from PySide6.QtCore import QDate, QTime, Qt
from PySide6.QtWidgets import (QComboBox, QDateEdit, QDialog, QDialogButtonBox, QDoubleSpinBox,
                               QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit,
                               QPlainTextEdit, QPushButton, QSpinBox, QTimeEdit, QVBoxLayout, QWidget)

import db as dbm
from widgets import (confirm, doctor_combo, fill_table, iso_qdate, make_table, money, qdate_iso,
                     selected_id)


def _date_edit(iso=None):
    e = QDateEdit()
    e.setCalendarPopup(True)
    e.setDisplayFormat("dd.MM.yyyy")
    e.setDate(iso_qdate(iso) if iso else QDate.currentDate())
    return e


def _small_text(h=62):
    e = QPlainTextEdit()
    e.setMaximumHeight(h)
    e.setTabChangesFocus(True)
    return e


class FormDialog(QDialog):
    """Kaydet / Vazgeç düğmeli temel kutu. Alt sınıf on_save() yazar:
    ValueError fırlatırsa mesaj kutu içinde gösterilir; False dönerse kutu açık kalır."""

    def __init__(self, title, parent=None, width=460, save_text="Kaydet"):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(width)
        self.root = QVBoxLayout(self)
        self.form = QFormLayout()
        self.form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        self.root.addLayout(self.form)
        self.error = QLabel()
        self.error.setStyleSheet("color:#c62828;font-weight:600")
        self.error.setWordWrap(True)
        self.error.hide()
        self.root.addWidget(self.error)
        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        self.buttons.button(QDialogButtonBox.StandardButton.Save).setText(save_text)
        self.buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Vazgeç")
        self.buttons.accepted.connect(self._try_accept)
        self.buttons.rejected.connect(self.reject)
        self.root.addWidget(self.buttons)

    def _try_accept(self):
        try:
            if self.on_save() is False:
                return
        except ValueError as e:
            self.error.setText(str(e))
            self.error.show()
            return
        self.accept()

    def on_save(self):
        raise NotImplementedError


# ------------------------------------------------------------------ giriş / kurulum
class LoginDialog(FormDialog):
    def __init__(self, db, parent=None):
        super().__init__("DişPlan — Giriş", parent, 360, "Giriş Yap")
        self.db, self.user = db, None
        self.f_user, self.f_pass = QLineEdit(), QLineEdit()
        self.f_pass.setEchoMode(QLineEdit.EchoMode.Password)
        self.form.addRow("Kullanıcı adı", self.f_user)
        self.form.addRow("Şifre", self.f_pass)

    def on_save(self):
        u = self.db.authenticate(self.f_user.text(), self.f_pass.text())
        if not u:
            self.f_pass.clear()
            raise ValueError("Kullanıcı adı veya şifre hatalı.")
        self.user = u


class SetupDialog(FormDialog):
    """İlk çalıştırmada yönetici hesabını oluşturur."""

    def __init__(self, db, parent=None):
        super().__init__("DişPlan — İlk Kurulum", parent, 420, "Hesabı Oluştur")
        self.db = db
        intro = QLabel("Hoş geldiniz! Başlamak için klinik yöneticisi hesabını oluşturun.\n"
                       "Doktorları ve diğer kullanıcıları sonra ekleyebilirsiniz.")
        intro.setWordWrap(True)
        self.root.insertWidget(0, intro)
        self.f_name, self.f_user = QLineEdit(), QLineEdit()
        self.f_pass, self.f_pass2 = QLineEdit(), QLineEdit()
        for f in (self.f_pass, self.f_pass2):
            f.setEchoMode(QLineEdit.EchoMode.Password)
        self.form.addRow("Ad Soyad", self.f_name)
        self.form.addRow("Kullanıcı adı", self.f_user)
        self.form.addRow("Şifre (en az 6)", self.f_pass)
        self.form.addRow("Şifre (tekrar)", self.f_pass2)

    def on_save(self):
        if self.f_pass.text() != self.f_pass2.text():
            raise ValueError("Şifreler aynı değil.")
        self.db.create_user(self.f_user.text(), self.f_name.text(), "admin", self.f_pass.text())


class PasswordDialog(FormDialog):
    def __init__(self, db, uid, username=None, parent=None):
        super().__init__("Şifre Değiştir", parent, 380)
        self.db, self.uid, self.username = db, uid, username
        self.f_old = QLineEdit()
        self.f_new, self.f_new2 = QLineEdit(), QLineEdit()
        for f in (self.f_old, self.f_new, self.f_new2):
            f.setEchoMode(QLineEdit.EchoMode.Password)
        if username:
            self.form.addRow("Mevcut şifre", self.f_old)
        self.form.addRow("Yeni şifre (en az 6)", self.f_new)
        self.form.addRow("Yeni şifre (tekrar)", self.f_new2)

    def on_save(self):
        if self.username and not self.db.authenticate(self.username, self.f_old.text()):
            raise ValueError("Mevcut şifre hatalı.")
        if self.f_new.text() != self.f_new2.text():
            raise ValueError("Yeni şifreler aynı değil.")
        self.db.set_password(self.uid, self.f_new.text())


class UserDialog(FormDialog):
    def __init__(self, db, parent=None):
        super().__init__("Yeni Kullanıcı", parent, 420)
        self.db = db
        self.f_name, self.f_user = QLineEdit(), QLineEdit()
        self.f_role = QComboBox()
        for key, label in dbm.ROLES.items():
            self.f_role.addItem(label, key)
        self.f_role.setCurrentIndex(self.f_role.findData("sekreter"))
        self.f_pass, self.f_pass2 = QLineEdit(), QLineEdit()
        for f in (self.f_pass, self.f_pass2):
            f.setEchoMode(QLineEdit.EchoMode.Password)
        self.form.addRow("Ad Soyad", self.f_name)
        self.form.addRow("Kullanıcı adı", self.f_user)
        self.form.addRow("Rol", self.f_role)
        self.form.addRow("Şifre (en az 6)", self.f_pass)
        self.form.addRow("Şifre (tekrar)", self.f_pass2)
        note = QLabel("Yönetici: her şey • Doktor: hasta, tedavi, röntgen, randevu • "
                      "Sekreter: hasta kaydı ve randevu (tedavi/röntgen yalnızca görüntüler)")
        note.setWordWrap(True)
        note.setStyleSheet("color:#607d8b")
        self.root.insertWidget(1, note)

    def on_save(self):
        if self.f_pass.text() != self.f_pass2.text():
            raise ValueError("Şifreler aynı değil.")
        self.db.create_user(self.f_user.text(), self.f_name.text(), self.f_role.currentData(), self.f_pass.text())


class DoctorDialog(FormDialog):
    def __init__(self, db, doctor=None, parent=None):
        super().__init__("Doktoru Düzenle" if doctor else "Yeni Doktor", parent, 420)
        self.db, self.doctor = db, doctor
        self.f_name = QLineEdit(doctor["full_name"] if doctor else "Dr. ")
        self.f_spec = QComboBox()
        self.f_spec.setEditable(True)
        self.f_spec.addItems(dbm.SPECIALTIES)
        self.f_spec.setCurrentText(doctor["specialty"] if doctor else dbm.SPECIALTIES[0])
        self.f_phone = QLineEdit(doctor["phone"] if doctor else "")
        self.form.addRow("Ad Soyad", self.f_name)
        self.form.addRow("Uzmanlık", self.f_spec)
        self.form.addRow("Telefon", self.f_phone)

    def on_save(self):
        self.db.save_doctor({"full_name": self.f_name.text(), "specialty": self.f_spec.currentText().strip(),
                             "phone": self.f_phone.text().strip()}, self.doctor["id"] if self.doctor else None)


# ------------------------------------------------------------------ hasta
class PatientForm(QWidget):
    def __init__(self, db, patient=None, parent=None):
        super().__init__(parent)
        self.db = db
        form = QFormLayout(self)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        self.f_name = QLineEdit()
        self.f_tc = QLineEdit()
        self.f_tc.setMaxLength(11)
        self.f_tc.setPlaceholderText("11 haneli (yabancı uyruklularda boş bırakın)")
        self.f_birth = QLineEdit()
        self.f_birth.setPlaceholderText("GG.AA.YYYY")
        self.f_gender = QComboBox()
        self.f_gender.addItems(dbm.GENDERS)
        self.f_gender.setCurrentText("Belirtilmemiş")
        self.f_phone, self.f_email, self.f_address = QLineEdit(), QLineEdit(), QLineEdit()
        self.f_blood = QComboBox()
        self.f_blood.addItems(dbm.BLOOD_TYPES)
        self.f_allergies, self.f_chronic = _small_text(), _small_text()
        self.f_meds, self.f_notes = _small_text(), _small_text(90)
        self.f_allergies.setPlaceholderText("Örn. Penisilin, lateks, lokal anestezik…")
        self.f_chronic.setPlaceholderText("Örn. Diyabet, hipertansiyon, kalp hastalığı, hamilelik…")
        self.f_meds.setPlaceholderText("Örn. Kan sulandırıcı (Coumadin), bifosfonat…")
        form.addRow("Ad Soyad *", self.f_name)
        form.addRow("TC Kimlik No", self.f_tc)
        form.addRow("Doğum tarihi", self.f_birth)
        form.addRow("Cinsiyet", self.f_gender)
        form.addRow("Telefon", self.f_phone)
        form.addRow("E-posta", self.f_email)
        form.addRow("Adres", self.f_address)
        form.addRow("Kan grubu", self.f_blood)
        form.addRow("Alerjiler", self.f_allergies)
        form.addRow("Kronik hastalıklar", self.f_chronic)
        form.addRow("Kullandığı ilaçlar", self.f_meds)
        form.addRow("Notlar", self.f_notes)
        if patient:
            self.load(patient)

    def load(self, p):
        self.f_name.setText(p["full_name"])
        self.f_tc.setText(p["tc_no"])
        self.f_birth.setText(dbm.fmt_date(p["birth_date"]))
        self.f_gender.setCurrentText(p["gender"] or "Belirtilmemiş")
        self.f_phone.setText(p["phone"])
        self.f_email.setText(p["email"])
        self.f_address.setText(p["address"])
        self.f_blood.setCurrentText(p["blood_type"] or "")
        self.f_allergies.setPlainText(p["allergies"])
        self.f_chronic.setPlainText(p["chronic_diseases"])
        self.f_meds.setPlainText(p["medications"])
        self.f_notes.setPlainText(p["notes"])

    def collect(self):
        birth = self.f_birth.text().strip()
        return {"full_name": self.f_name.text(), "tc_no": self.f_tc.text(),
                "birth_date": dbm.parse_date(birth) if birth else "",
                "gender": self.f_gender.currentText(), "phone": self.f_phone.text(),
                "email": self.f_email.text(), "address": self.f_address.text(),
                "blood_type": self.f_blood.currentText(),
                "allergies": self.f_allergies.toPlainText(), "chronic_diseases": self.f_chronic.toPlainText(),
                "medications": self.f_meds.toPlainText(), "notes": self.f_notes.toPlainText()}

    def save(self, pid=None):
        return self.db.save_patient(self.collect(), pid)


class PatientDialog(FormDialog):
    def __init__(self, db, parent=None):
        super().__init__("Yeni Hasta", parent, 560)
        self.saved_id = None
        self.pform = PatientForm(db)
        self.root.insertWidget(0, self.pform)

    def on_save(self):
        self.saved_id = self.pform.save()


class PatientPicker(QDialog):
    """Aranabilir hasta seçici. Seçilen hasta self.patient_id içinde."""

    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db, self.patient_id = db, None
        self.setWindowTitle("Hasta Seç")
        self.resize(640, 460)
        root = QVBoxLayout(self)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Ad soyad, TC kimlik no veya telefon ile arayın…")
        self.search.textChanged.connect(self.refresh)
        root.addWidget(self.search)
        self.table = make_table(["Ad Soyad", "TC Kimlik No", "Telefon", "Yaş"], stretch=0)
        self.table.doubleClicked.connect(self._choose)
        root.addWidget(self.table, 1)
        row = QHBoxLayout()
        new = QPushButton("Yeni Hasta Kaydı…")
        new.clicked.connect(self._new)
        row.addWidget(new)
        row.addStretch(1)
        ok = QPushButton("Seç")
        ok.setDefault(True)
        ok.clicked.connect(self._choose)
        cancel = QPushButton("Vazgeç")
        cancel.clicked.connect(self.reject)
        row.addWidget(cancel)
        row.addWidget(ok)
        root.addLayout(row)
        self.refresh()
        self.search.setFocus()

    def refresh(self):
        rows = self.db.search_patients(self.search.text())
        fill_table(self.table, [(r["full_name"], r["tc_no"], r["phone"], dbm.age_from(r["birth_date"]) or "")
                                for r in rows], [r["id"] for r in rows])
        if rows and selected_id(self.table) is None:
            self.table.selectRow(0)

    def _choose(self, *_):
        pid = selected_id(self.table)
        if pid:
            self.patient_id = pid
            self.accept()

    def _new(self):
        dlg = PatientDialog(self.db, self)
        if dlg.exec():
            self.patient_id = dlg.saved_id
            self.accept()


# ------------------------------------------------------------------ randevu
class AppointmentDialog(FormDialog):
    def __init__(self, db, appt=None, patient_id=None, date_iso=None, doctor_id=None, parent=None):
        super().__init__("Randevuyu Düzenle" if appt else "Yeni Randevu", parent, 520)
        self.db, self.appt, self.saved_id = db, appt, None
        self.patient_id = appt["patient_id"] if appt else patient_id

        self.lbl_patient = QLabel()
        self.lbl_patient.setStyleSheet("font-weight:600")
        btn = QPushButton("Hasta Seç…")
        btn.clicked.connect(self._pick)
        row = QHBoxLayout()
        row.addWidget(self.lbl_patient, 1)
        row.addWidget(btn)
        self.form.addRow("Hasta *", row)

        self.f_date = _date_edit(appt["date"] if appt else date_iso)
        self.f_time = QTimeEdit(QTime.fromString(appt["time"], "HH:mm") if appt else QTime(9, 0))
        self.f_time.setDisplayFormat("HH:mm")
        self.f_dur = QSpinBox()
        self.f_dur.setRange(15, 240)
        self.f_dur.setSingleStep(15)
        self.f_dur.setSuffix(" dk")
        self.f_dur.setValue(appt["duration_min"] if appt else 30)
        self.f_doctor = doctor_combo(db, appt["doctor_id"] if appt else doctor_id)
        self.f_proc = QComboBox()
        self.f_proc.setEditable(True)
        self.f_proc.addItems(dbm.PROCEDURES)
        self.f_proc.setCurrentText(appt["procedure"] if appt else "Muayene")
        self.f_status = QComboBox()
        self.f_status.addItems(dbm.STATUSES)
        self.f_status.setCurrentText(appt["status"] if appt else "Bekliyor")
        self.f_notes = _small_text()
        self.f_notes.setPlainText(appt["notes"] if appt else "")
        when = QHBoxLayout()
        when.addWidget(self.f_date)
        when.addWidget(self.f_time)
        when.addWidget(self.f_dur)
        self.form.addRow("Tarih / Saat / Süre", when)
        self.form.addRow("Doktor *", self.f_doctor)
        self.form.addRow("Yapılacak işlem", self.f_proc)
        self.form.addRow("Durum", self.f_status)
        self.form.addRow("Not", self.f_notes)
        self._show_patient()

    def _show_patient(self):
        p = self.db.get_patient(self.patient_id) if self.patient_id else None
        self.lbl_patient.setText(p["full_name"] + (f"   •   {p['phone']}" if p["phone"] else "") if p else "— seçilmedi —")

    def _pick(self):
        dlg = PatientPicker(self.db, self)
        if dlg.exec() and dlg.patient_id:
            self.patient_id = dlg.patient_id
            self._show_patient()
            if not self.appt:  # yeni randevuda hastanın son baktığı doktoru öner
                idx = self.f_doctor.findData(self.db.default_doctor_id(self.patient_id))
                if idx >= 0:
                    self.f_doctor.setCurrentIndex(idx)

    def on_save(self):
        if not self.patient_id:
            raise ValueError("Lütfen bir hasta seçin.")
        doctor = self.f_doctor.currentData()
        if not doctor:
            raise ValueError("Önce Doktorlar sekmesinden bir doktor ekleyin.")
        time = dbm.norm_time(self.f_time.time().toString("HH:mm"))
        date_iso = qdate_iso(self.f_date.date())
        status = self.f_status.currentText()
        aid = self.appt["id"] if self.appt else None
        if status not in ("İptal", "Gelmedi"):
            c = self.db.find_conflict(doctor, date_iso, time, self.f_dur.value(), aid)
            if c and not confirm(
                    self, "Randevu çakışması",
                    f"{self.f_doctor.currentText().split('  (')[0]} için bu saatte başka bir randevu var:\n\n"
                    f"{c['time']} ({c['duration_min']} dk) — {c['patient']}\n\nYine de kaydedilsin mi?",
                    yes="Yine de Kaydet", no="Vazgeç"):
                return False
        self.saved_id = self.db.save_appointment({
            "patient_id": self.patient_id, "doctor_id": doctor, "date": date_iso, "time": time,
            "duration_min": self.f_dur.value(), "procedure": self.f_proc.currentText().strip(),
            "status": status, "notes": self.f_notes.toPlainText().strip()}, aid)


# ------------------------------------------------------------------ tedavi / röntgen
class TreatmentDialog(FormDialog):
    def __init__(self, db, patient_id, treat=None, defaults=None, parent=None):
        super().__init__("İşlemi Düzenle" if treat else "Yeni İşlem Kaydı", parent, 500)
        self.db, self.pid, self.treat, self.saved_id = db, patient_id, treat, None
        d = defaults or {}
        self.f_date = _date_edit(treat["date"] if treat else d.get("date"))
        self.f_doctor = doctor_combo(db, treat["doctor_id"] if treat else (d.get("doctor_id") or db.default_doctor_id(patient_id)))
        self.f_teeth = QLineEdit(treat["tooth_no"] if treat else d.get("tooth_no", ""))
        self.f_teeth.setPlaceholderText("FDI numarası, birden fazla için virgül: 16, 24 (genel işlemde boş)")
        self.f_proc = QComboBox()
        self.f_proc.setEditable(True)
        self.f_proc.addItems(dbm.PROCEDURES)
        self.f_proc.setCurrentText(treat["procedure"] if treat else d.get("procedure", "Muayene"))
        self.f_fee, self.f_paid = QDoubleSpinBox(), QDoubleSpinBox()
        for sp, val in ((self.f_fee, treat["fee"] if treat else 0), (self.f_paid, treat["paid"] if treat else 0)):
            sp.setRange(0, 10_000_000)
            sp.setDecimals(2)
            sp.setSuffix(" ₺")
            sp.setGroupSeparatorShown(True)
            sp.setValue(val)
        self.f_notes = _small_text(90)
        self.f_notes.setPlainText(treat["notes"] if treat else d.get("notes", ""))
        self.form.addRow("Tarih", self.f_date)
        self.form.addRow("Tedaviyi yapan doktor *", self.f_doctor)
        self.form.addRow("Diş no", self.f_teeth)
        self.form.addRow("Yapılan işlem *", self.f_proc)
        self.form.addRow("Ücret", self.f_fee)
        self.form.addRow("Ödenen", self.f_paid)
        self.form.addRow("Notlar", self.f_notes)
        hint = QLabel("Dolgu, kanal tedavisi, çekim, kron ve implant kaydı ilgili dişin şemadaki durumunu otomatik günceller.")
        hint.setWordWrap(True)
        hint.setStyleSheet("color:#607d8b")
        self.root.insertWidget(1, hint)

    def on_save(self):
        if not self.f_doctor.currentData():
            raise ValueError("Tedaviyi yapan doktoru seçin (yoksa önce Doktorlar sekmesinden ekleyin).")
        self.saved_id = self.db.save_treatment({
            "patient_id": self.pid, "doctor_id": self.f_doctor.currentData(), "date": qdate_iso(self.f_date.date()),
            "tooth_no": self.f_teeth.text(), "procedure": self.f_proc.currentText(),
            "notes": self.f_notes.toPlainText().strip(), "fee": self.f_fee.value(), "paid": self.f_paid.value()},
            self.treat["id"] if self.treat else None)


class XrayDialog(FormDialog):
    FILTER = "Röntgen / görüntü (*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.dcm);;Tüm dosyalar (*)"

    def __init__(self, db, patient_id, xray=None, parent=None):
        super().__init__("Röntgen Bilgilerini Düzenle" if xray else "Röntgen Ekle", parent, 500)
        self.db, self.pid, self.xray, self.files, self.saved_ids = db, patient_id, xray, [], []
        if not xray:
            self.lbl_files = QLabel("Dosya seçilmedi")
            btn = QPushButton("Dosya Seç…")
            btn.clicked.connect(self._pick)
            row = QHBoxLayout()
            row.addWidget(self.lbl_files, 1)
            row.addWidget(btn)
            self.form.addRow("Dosya(lar) *", row)
        self.f_date = _date_edit(xray["date"] if xray else None)
        self.f_kind = QComboBox()
        self.f_kind.setEditable(True)
        self.f_kind.addItems(dbm.XRAY_KINDS)
        self.f_kind.setCurrentText(xray["kind"] if xray else dbm.XRAY_KINDS[0])
        self.f_doctor = doctor_combo(db, xray["doctor_id"] if xray else db.default_doctor_id(patient_id), allow_none=False)
        self.f_teeth = QLineEdit(xray["tooth_no"] if xray else "")
        self.f_teeth.setPlaceholderText("İlgili dişler (isteğe bağlı): 36, 37")
        self.f_notes = _small_text(90)
        self.f_notes.setPlainText(xray["notes"] if xray else "")
        self.form.addRow("Çekim tarihi", self.f_date)
        self.form.addRow("Röntgen türü", self.f_kind)
        self.form.addRow("İsteyen / bakan doktor", self.f_doctor)
        self.form.addRow("İlgili diş(ler)", self.f_teeth)
        self.form.addRow("Bulgu / not", self.f_notes)
        if not xray:
            tip = QLabel("Birden fazla dosya seçebilirsiniz; hepsine aynı bilgiler uygulanır.")
            tip.setStyleSheet("color:#607d8b")
            self.root.insertWidget(1, tip)

    def _pick(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Röntgen dosyalarını seçin", "", self.FILTER)
        if files:
            self.files = files
            self.lbl_files.setText(os.path.basename(files[0]) if len(files) == 1 else f"{len(files)} dosya seçildi")

    def on_save(self):
        data = {"date": qdate_iso(self.f_date.date()), "kind": self.f_kind.currentText().strip(),
                "doctor_id": self.f_doctor.currentData(), "tooth_no": self.f_teeth.text(),
                "notes": self.f_notes.toPlainText().strip()}
        if self.xray:
            teeth = ", ".join(str(t) for t in dbm.parse_teeth(data["tooth_no"]))
            self.db.ex("UPDATE xrays SET date=?, kind=?, doctor_id=?, tooth_no=?, notes=? WHERE id=?",
                       (data["date"], data["kind"], data["doctor_id"], teeth, data["notes"], self.xray["id"]))
            return
        if not self.files:
            raise ValueError("Lütfen en az bir röntgen dosyası seçin.")
        dbm.parse_teeth(data["tooth_no"])  # dosyalar kopyalanmadan önce doğrula
        self.saved_ids = [self.db.add_xray(self.pid, f, data) for f in self.files]
