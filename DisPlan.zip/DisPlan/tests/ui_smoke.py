"""Arayüz duman testi: örnek veriyle uygulamayı sanal ekranda açar, ekran görüntüleri kaydeder.

Kullanım:  python tests/ui_smoke.py <çıktı_klasörü>
"""
import datetime as dt
import os
import random
import sys
import tempfile

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
OUT = sys.argv[1] if len(sys.argv) > 1 else tempfile.mkdtemp()
os.makedirs(OUT, exist_ok=True)
os.environ["DISPLAN_DATA"] = tempfile.mkdtemp()

from PIL import Image, ImageDraw, ImageFilter  # noqa: E402
from PySide6.QtGui import QFont  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

import db as dbm  # noqa: E402
import app as appmod  # noqa: E402
from card import PatientCard  # noqa: E402
from dialogs import AppointmentDialog, TreatmentDialog, XrayDialog, PatientDialog, LoginDialog  # noqa: E402
from widgets import XrayViewer  # noqa: E402


def check(cond, msg):
    print(("OK   " if cond else "FAIL ") + msg)
    if not cond:
        raise SystemExit(1)


def fake_xray(path, panoramic=True):
    random.seed(4)
    w, h = (1400, 640) if panoramic else (520, 700)
    im = Image.new("L", (w, h), 28)
    d = ImageDraw.Draw(im)
    d.ellipse((w * .08, h * .05, w * .92, h * 1.25), outline=70, width=40)
    for i in range(16):
        x = w * (.2 + .6 * i / 15)
        d.rounded_rectangle((x - 22, h * .36, x + 22, h * .52), 10, fill=205 - random.randint(0, 25))
        d.rounded_rectangle((x - 22, h * .56, x + 22, h * .72), 10, fill=200 - random.randint(0, 25))
    d.rectangle((w * .42, h * .57, w * .45, h * .70), fill=250)  # dolgu
    im.filter(ImageFilter.GaussianBlur(2)).save(path)


app = QApplication([])
app.setStyle("Fusion")
app.setFont(QFont("DejaVu Sans", 10))
app.setStyleSheet(appmod.STYLE)

db = dbm.DB(os.environ["DISPLAN_DATA"])
db.create_user("admin", "Klinik Yöneticisi", "admin", "sifre123")
db.create_user("sekreter", "Elif Sekreter", "sekreter", "sifre123")
d1 = db.save_doctor({"full_name": "Dr. Ayşe Yılmaz", "specialty": "Endodonti", "phone": "0532 111 22 33"})
d2 = db.save_doctor({"full_name": "Dr. Mehmet Kaya", "specialty": "Ortodonti"})
d3 = db.save_doctor({"full_name": "Dr. Zeynep Demir", "specialty": "İmplantoloji"})
today = dt.date.today()
iso = lambda n: (today + dt.timedelta(days=n)).isoformat()  # noqa: E731

p1 = db.save_patient({"full_name": "Çağla Şahin", "tc_no": "10000000146", "birth_date": "1990-05-20", "gender": "Kadın",
                      "phone": "0555 123 45 67", "blood_type": "A Rh+", "allergies": "Penisilin, lateks",
                      "chronic_diseases": "Tip 2 diyabet", "medications": "Metformin", "notes": "Sıkıntılı bir hasta değil; anksiyetesi var, sabırlı yaklaşın."})
p2 = db.save_patient({"full_name": "Burak Öztürk", "birth_date": "1985-11-02", "gender": "Erkek", "phone": "0544 765 43 21"})
p3 = db.save_patient({"full_name": "İrem Yıldız", "birth_date": "2016-03-14", "gender": "Kadın", "phone": "0533 000 11 22"})
p4 = db.save_patient({"full_name": "Ömer Faruk Güneş", "birth_date": "1972-07-30", "gender": "Erkek", "phone": "0505 222 33 44"})

db.save_treatment({"patient_id": p1, "doctor_id": d1, "date": iso(-60), "tooth_no": "36", "procedure": "Kanal Tedavisi", "fee": 3500, "paid": 3500, "notes": "3 kanal, tek seans"})
db.save_treatment({"patient_id": p1, "doctor_id": d1, "date": iso(-45), "tooth_no": "36", "procedure": "Kron / Kaplama", "fee": 6000, "paid": 4000})
db.save_treatment({"patient_id": p1, "doctor_id": d2, "date": iso(-12), "tooth_no": "46, 47", "procedure": "Dolgu", "fee": 2200, "paid": 2200})
db.save_treatment({"patient_id": p1, "doctor_id": d2, "date": iso(-5), "tooth_no": "18", "procedure": "Diş Çekimi", "fee": 900, "paid": 0, "notes": "Gömülü yirmilik, dikiş atıldı. 7. gün kontrol."})
db.set_tooth_status(p1, 24, "Çürük")
db.set_tooth_status(p1, 15, "Planlanan Tedavi")
db.save_treatment({"patient_id": p2, "doctor_id": d3, "date": iso(-20), "tooth_no": "21", "procedure": "İmplant", "fee": 18000, "paid": 9000})
db.save_treatment({"patient_id": p3, "doctor_id": d2, "date": iso(-3), "tooth_no": "55", "procedure": "Fluorlu Uygulama", "fee": 400, "paid": 400})

for t, pid, doc, proc, st in (("09:00", p1, d1, "Kontrol", "Tamamlandı"), ("09:30", p2, d3, "İmplant kontrolü", "Geldi"),
                              ("10:00", p3, d2, "Muayene", "Bekliyor"), ("10:30", p4, d1, "Kanal Tedavisi", "Bekliyor"),
                              ("11:30", p1, d2, "Dikiş alma", "Gelmedi"), ("14:00", p2, d3, "Muayene", "İptal")):
    db.save_appointment({"patient_id": pid, "doctor_id": doc, "date": iso(0), "time": t, "duration_min": 30, "procedure": proc, "status": st})
db.save_appointment({"patient_id": p1, "doctor_id": d2, "date": iso(7), "time": "15:00", "duration_min": 30, "procedure": "Kontrol", "status": "Bekliyor"})

for i, (kind, n, pan) in enumerate((("Panoramik", -12, True), ("Periapikal", -45, False), ("Bitewing", -60, False))):
    f = os.path.join(OUT, f"xray_src_{i}.png")
    fake_xray(f, pan)
    db.add_xray(p1, f, {"date": iso(n), "kind": kind, "doctor_id": d1, "tooth_no": "36" if not pan else "", "notes": "Periapikal lezyon izlenmedi." if i == 1 else ""})
    os.remove(f)

admin = db.authenticate("admin", "sifre123")
sek = db.authenticate("sekreter", "sifre123")


def shot(w, name):
    app.processEvents()
    w.grab().save(os.path.join(OUT, name + ".png"))
    print("     ->", name + ".png")


# ---- ana pencere
win = appmod.MainWindow(db, admin)
win.show()
app.processEvents()
shot(win, "01_randevular")
check(win.p_appt.table.rowCount() == 6, "bugünkü 6 randevu listelendi")
win.tabs.setCurrentWidget(win.p_pat)
shot(win, "02_hastalar")
check(win.p_pat.table.rowCount() == 4, "4 hasta listelendi")
row0 = [win.p_pat.table.item(0, c).text() for c in range(7)]
check(row0[0] == "Burak Öztürk" and row0[4] == "İmplant" and row0[6] == "Dr. Zeynep Demir", "hasta listesinde son işlem + doktor görünüyor: %s" % row0)
win.p_pat.search.setText("cagla")
check(win.p_pat.table.rowCount() == 1, "Türkçe harf duyarsız arama arayüzde çalışıyor")
win.p_pat.search.setText("")
win.tabs.setCurrentWidget(win.p_doc)
shot(win, "03_doktorlar")
win.tabs.setCurrentWidget(win.p_usr)
shot(win, "04_kullanicilar")

# ---- hasta kartı
win.open_card(p1)
card = win.cards[p1]
app.processEvents()
check("Dr. Ayşe Yılmaz" in card.stat["doctor"].text(), "kart: son bakan doktor = bugünkü tamamlanan randevunun doktoru (Dr. Ayşe)")
check("Diş Çekimi" in card.stat["last"].text() and "Dr. Mehmet Kaya" in card.stat["last"].text(),
      "kart: son işlem = Diş Çekimi, işlemi yapan Dr. Mehmet Kaya")
check("Penisilin" in card.h_alert.text(), "kart: alerji uyarısı görünüyor")
shot(card, "05_kart_genel")
card.tabs.setCurrentIndex(1)
card.odo.toothClicked.emit(36)
card._on_tooth(36)
shot(card, "06_kart_dis_semasi")
card.chk_decid.setChecked(True)
card._on_tooth(24)
shot(card, "07_kart_dis_semasi_sut")
card.chk_decid.setChecked(False)
check(card.db.get_tooth_status(p1)[36] == "Kaplama / Kron", "diş 36 durumu = Kaplama / Kron (son işlemden)")
check(card.db.get_tooth_status(p1)[18] == "Çekilmiş / Eksik", "diş 18 durumu = Çekilmiş / Eksik")
card.tabs.setCurrentIndex(2)
shot(card, "08_kart_tedaviler")
check(card.t_table.rowCount() == 4, "4 tedavi satırı")
card.tabs.setCurrentIndex(3)
card.x_list.setCurrentRow(0)
shot(card, "09_kart_rontgenler")
check(card.x_list.count() == 3, "3 röntgen küçük resmi")
card.tabs.setCurrentIndex(4)
shot(card, "10_kart_randevular")

# ---- röntgen görüntüleyici
x = card._current_xray()
v = XrayViewer(db.xray_abs_path(x["file_path"]), "Panoramik — Çağla Şahin", card._xray_html(x, db.get_doctor(x["doctor_id"])))
v.show()
app.processEvents()
shot(v, "11_rontgen_goruntuleyici")
v.s_contrast.setValue(40)
v.c_invert.setChecked(True)
v._apply()
shot(v, "12_rontgen_negatif")
v.close()

# ---- iletişim kutuları
dlg = AppointmentDialog(db, patient_id=p1, doctor_id=d2)
dlg.show()
shot(dlg, "13_randevu_dialog")
dlg.close()
dlg = TreatmentDialog(db, p1, defaults={"tooth_no": "36", "procedure": "Dolgu"})
dlg.show()
shot(dlg, "14_islem_dialog")
dlg.close()
dlg = XrayDialog(db, p1)
dlg.show()
shot(dlg, "15_rontgen_dialog")
dlg.close()

# ---- sekreter rolü: yalnızca görüntüleme
win2 = appmod.MainWindow(db, sek)
check(win2.p_doc is None and win2.p_usr is None, "sekreter: doktor/kullanıcı sekmeleri yok")
c2 = PatientCard(db, sek, p1, lambda: None)
check(not c2.btn_t_add.isEnabled() and not c2.btn_x_add.isEnabled(), "sekreter: tedavi/röntgen ekleme kapalı")
check(not win2.p_pat.btn_del.isEnabled(), "sekreter: hasta silme kapalı")
win2.hide()  # close() ortak veritabanı bağlantısını kapatırdı (testte iki pencere aynı db'yi paylaşıyor)
c2.hide()

# ---- uygulama içi akış: çakışma + durum -> tamamlandı
dlg = AppointmentDialog(db, patient_id=p4, doctor_id=d1, date_iso=iso(0))
dlg.f_time.setTime(dlg.f_time.time().fromString("10:15", "HH:mm"))
c = db.find_conflict(d1, iso(0), "10:15", 30)
check(c is not None, "10:15 için Dr. Ayşe çakışması bulundu (10:00 randevusu)")
dlg.close()

print("\nTÜM ARAYÜZ TESTLERİ GEÇTİ — görüntüler:", OUT)
