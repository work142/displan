import os, sys, tempfile, zipfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import db

def check(cond, msg):
    print(("OK   " if cond else "FAIL ") + msg)
    if not cond:
        raise SystemExit(1)

tmp = tempfile.mkdtemp()
d = db.DB(tmp)

# kullanıcı
check(d.user_count() == 0, "boş başlangıç")
d.create_user("Admin", "Yönetici Kişi", "admin", "sifre123")
check(d.authenticate("admin", "sifre123") is not None, "doğru şifre girer")
check(d.authenticate("admin", "yanlis") is None, "yanlış şifre girmez")
try: d.create_user("x", "X", "admin", "123"); check(False, "kısa şifre reddedilmeli")
except ValueError: check(True, "kısa şifre reddedildi")
try: d.set_user_active(1, False); check(False, "son admin pasifleşmemeli")
except ValueError: check(True, "son admin korundu")

# doktor
d1 = d.save_doctor({"full_name": "Dr. Ayşe Yılmaz", "specialty": "Endodonti"})
d2 = d.save_doctor({"full_name": "Dr. Mehmet Kaya", "specialty": "Ortodonti"})

# TC doğrulama (geçerli örnek: 10000000146)
check(db.valid_tc("10000000146"), "geçerli TC kabul")
check(not db.valid_tc("12345678901"), "geçersiz TC red")
p = d.save_patient({"full_name": "Çağla Şahin", "tc_no": "10000000146", "birth_date": "1990-05-20", "allergies": "Penisilin"})
try: d.save_patient({"full_name": "Aynı TC", "tc_no": "10000000146"}); check(False, "mükerrer TC red")
except ValueError: check(True, "mükerrer TC reddedildi")
check(len(d.search_patients("cagla")) == 1, "Türkçe harf duyarsız arama (cagla→Çağla)")
check(len(d.search_patients("SAHİN")) == 1 or len(d.search_patients("sahin")) == 1, "arama: şahin")
check(len(d.search_patients("10000000146")) == 1, "TC ile arama")

# Türkçe alfabe sıralaması (SQLite NOCASE Ç/İ/Ö/Ş/Ü'yü sona atardı)
names = ["Zeynep", "Şule", "Ömer", "İrem", "Irmak", "Ayşe", "Çağla", "Ali", "Ümit", "Gül", "Ğ-yok", "Hasan"]
check(sorted(names, key=db.tr_key) == ["Ali", "Ayşe", "Çağla", "Gül", "Ğ-yok", "Hasan", "Irmak", "İrem", "Ömer", "Şule", "Ümit", "Zeynep"],
      "Türkçe alfabe sıralaması doğru (ç, ğ, ı, i, ö, ş, ü)")
for n in ("İlker Demir", "Ömer Yaz", "Çiğdem Ak", "Burak Er"):
    d.save_patient({"full_name": n})
order = [r["full_name"] for r in d.search_patients("") if r["full_name"] in ("İlker Demir", "Ömer Yaz", "Çiğdem Ak", "Burak Er")]
check(order == ["Burak Er", "Çiğdem Ak", "İlker Demir", "Ömer Yaz"], "hasta listesi Türkçe sırada: %s" % order)
for n in ("İlker Demir", "Ömer Yaz", "Çiğdem Ak", "Burak Er"):
    d.delete_patient(d.one("SELECT id FROM patients WHERE full_name=?", (n,))["id"])

# randevu + çakışma
a1 = d.save_appointment({"patient_id": p, "doctor_id": d1, "date": "2026-11-20", "time": "10:00", "duration_min": 30, "procedure": "Muayene"})
c = d.find_conflict(d1, "2026-11-20", "10:15", 30)
check(c is not None and c["id"] == a1, "çakışma yakalandı")
check(d.find_conflict(d1, "2026-11-20", "10:30", 30) is None, "ardışık randevu çakışmaz")
check(d.find_conflict(d2, "2026-11-20", "10:00", 30) is None, "başka doktor çakışmaz")
check(d.find_conflict(d1, "2026-11-20", "10:00", 30, exclude_id=a1) is None, "kendisiyle çakışmaz")
d.set_appointment_status(a1, "İptal")
check(d.find_conflict(d1, "2026-11-20", "10:00", 30) is None, "iptal edilen randevu slotu boşaltır")

# tedavi, son işlem, doktor, diş şeması
d.save_treatment({"patient_id": p, "doctor_id": d1, "date": "2026-10-01", "tooth_no": "36", "procedure": "Kanal Tedavisi", "fee": 3000, "paid": 1000})
d.save_treatment({"patient_id": p, "doctor_id": d2, "date": "2026-11-05", "tooth_no": "46, 47", "procedure": "Dolgu", "fee": 1500, "paid": 1500})
s = d.patient_summary(p)
check(s["last"]["procedure"] == "Dolgu" and s["doctor"] == "Dr. Mehmet Kaya", "son işlem ve bakan doktor doğru")
check(s["balance"] == 2000, "kalan borç = 2000")
ts = d.get_tooth_status(p)
check(ts == {36: "Kanal Tedavisi", 46: "Dolgu", 47: "Dolgu"}, "işlem diş şemasını otomatik güncelledi")
check(len(d.treatments_for_tooth(p, 47)) == 1, "dişe göre geçmiş")
try: d.save_treatment({"patient_id": p, "date": "2026-11-06", "tooth_no": "99", "procedure": "Dolgu"}); check(False, "geçersiz diş no")
except ValueError: check(True, "geçersiz FDI diş numarası reddedildi")
row = d.search_patients("")[0]
check(row["last_proc"] == "Dolgu" and row["last_doctor"] == "Dr. Mehmet Kaya", "hasta listesinde son işlem/doktor")

# röntgen
from PIL import Image
img = os.path.join(tmp, "src.png"); Image.new("L", (300, 200), 128).save(img)
x = d.add_xray(p, img, {"date": "2026-11-05", "kind": "Panoramik", "doctor_id": d1, "tooth_no": "36"})
check(os.path.exists(d.xray_abs_path(d.get_xray(x)["file_path"])), "röntgen kopyalandı")
check(d.patient_summary(p)["xray_count"] == 1, "röntgen sayısı")
d.delete_xray(x)
check(not os.path.exists(d.xray_abs_path(f"{p}/nothing")) and d.patient_summary(p)["xray_count"] == 0, "röntgen silindi")

# yedek
d.add_xray(p, img, {"date": "2026-11-05", "kind": "Periapikal"})
z = os.path.join(tmp, "yedek.zip"); d.backup(z)
names = zipfile.ZipFile(z).namelist()
check("displan.db" in names and any(n.startswith("xrays") for n in names), "yedek db + röntgen içeriyor")
check(os.path.exists(d.auto_backup()), "otomatik yedek")

# hasta silinince bağlı kayıtlar da silinir
d.delete_patient(p)
check(d.one("SELECT COUNT(*) c FROM treatments")["c"] == 0 and d.one("SELECT COUNT(*) c FROM appointments")["c"] == 0, "cascade silme")
# ---- yedekten geri yükleme
tmp2 = tempfile.mkdtemp()
r = db.DB(tmp2)
rp = r.save_patient({"full_name": "Yedekteki Hasta"})
r.add_xray(rp, img, {"date": "2026-11-05", "kind": "Panoramik"})
bak = os.path.join(tmp2, "bak.zip")
r.backup(bak)
r.save_patient({"full_name": "Sonradan Eklenen"})
r.delete_xray(r.list_xrays(rp)[0]["id"])
check(r.one("SELECT COUNT(*) c FROM patients")["c"] == 2, "geri yükleme öncesi 2 hasta var")

# geçersiz yedek: mevcut veriye dokunulmamalı
bad = os.path.join(tmp2, "bad.zip")
with zipfile.ZipFile(bad, "w") as z:
    z.writestr("baska.txt", "x")
try: r.restore(bad); check(False, "geçersiz yedek reddedilmeli")
except ValueError: check(True, "geçersiz yedek (displan.db yok) reddedildi")
junk = os.path.join(tmp2, "junk.zip")
with zipfile.ZipFile(junk, "w") as z:
    z.writestr("displan.db", "bu bir sqlite dosyası değil")
try: r.restore(junk); check(False, "bozuk veritabanı reddedilmeli")
except ValueError: check(True, "bozuk displan.db reddedildi")
check(r.one("SELECT COUNT(*) c FROM patients")["c"] == 2, "reddedilen yedeklerde mevcut veri korundu")

# zip-slip: dışarı yazmaya çalışan girdiler yok sayılmalı
evil = os.path.join(tmp2, "evil.zip")
with zipfile.ZipFile(bak) as zi, zipfile.ZipFile(evil, "w") as zo:
    for n in zi.namelist():
        zo.writestr(n, zi.read(n))
    zo.writestr("xrays/../../zip_slip.txt", "kotu")
    zo.writestr("../zip_slip2.txt", "kotu")
safety = r.restore(evil)
check(os.path.exists(safety), "geri yükleme öncesi güvenlik kopyası alındı")
check(not os.path.exists(os.path.join(os.path.dirname(tmp2), "zip_slip.txt")) and
      not os.path.exists(os.path.join(os.path.dirname(tmp2), "zip_slip2.txt")) and
      not os.path.exists(os.path.join(tmp2, "zip_slip.txt")), "zip-slip girdileri yazılmadı")
r2 = db.DB(tmp2)
check([x["full_name"] for x in r2.search_patients("")] == ["Yedekteki Hasta"], "geri yükleme sonrası yalnızca yedekteki hasta var")
check(len(r2.list_xrays(rp)) == 1 and os.path.exists(r2.xray_abs_path(r2.list_xrays(rp)[0]["file_path"])), "röntgen dosyası da geri geldi")

print("\nTÜM VERİ KATMANI TESTLERİ GEÇTİ")
