"""Diyalog akışları: ilk kurulum, giriş, doğrulama hataları (sanal ekranda)."""
import os, sys, tempfile
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from PySide6.QtWidgets import QApplication
import db as dbm
from dialogs import SetupDialog, LoginDialog, PatientDialog, DoctorDialog, UserDialog, PasswordDialog, TreatmentDialog, XrayDialog

def check(c, m):
    print(("OK   " if c else "FAIL ") + m)
    if not c: raise SystemExit(1)

app = QApplication([])
db = dbm.DB(tempfile.mkdtemp())

# ilk kurulum
s = SetupDialog(db)
s.f_name.setText("Dt. Yönetici"); s.f_user.setText("Yonetici"); s.f_pass.setText("abc123"); s.f_pass2.setText("farkli")
s._try_accept()
check(s.error.isVisible() is False and "aynı değil" in s.error.text() and db.user_count() == 0, "kurulum: şifreler farklıysa hesap açılmaz")
s.f_pass2.setText("abc123"); s._try_accept()
check(db.user_count() == 1 and s.result() == 1, "kurulum: yönetici hesabı oluştu ve kutu kapandı")
check(db.authenticate("YONETICI", "abc123") is not None, "kullanıcı adı büyük/küçük harf duyarsız")

# giriş
l = LoginDialog(db); l.f_user.setText("yonetici"); l.f_pass.setText("yanlis"); l._try_accept()
check(l.user is None and "hatalı" in l.error.text() and l.result() == 0, "giriş: yanlış şifre reddedildi, kutu açık")
l.f_pass.setText("abc123"); l._try_accept()
check(l.user is not None and l.user["role"] == "admin", "giriş: doğru şifre")

# hasta formu doğrulamaları
p = PatientDialog(db)
p._try_accept(); check("Ad Soyad" in p.error.text(), "hasta: ad soyad boşsa uyarı")
p.pform.f_name.setText("Test Hasta"); p.pform.f_tc.setText("12345678901"); p._try_accept()
check("TC Kimlik No geçersiz" in p.error.text(), "hasta: geçersiz TC uyarısı")
p.pform.f_tc.setText(""); p.pform.f_birth.setText("31.02.2020"); p._try_accept()
check("GG.AA.YYYY" in p.error.text(), "hasta: geçersiz doğum tarihi uyarısı")
p.pform.f_birth.setText("14.03.1988"); p._try_accept()
check(p.saved_id and dbm.age_from(db.get_patient(p.saved_id)["birth_date"]) is not None, "hasta: geçerli kayıt oluştu")

# doktor + kullanıcı
d = DoctorDialog(db); d.f_name.setText("Dr. Ali Veli"); d._try_accept()
check(len(db.list_doctors()) == 1, "doktor eklendi")
u = UserDialog(db); u.f_name.setText("Sek"); u.f_user.setText("sek"); u.f_pass.setText("123456"); u.f_pass2.setText("123456"); u._try_accept()
check(db.authenticate("sek", "123456")["role"] == "sekreter", "kullanıcı: varsayılan rol sekreter")
pw = PasswordDialog(db, db.authenticate("sek", "123456")["id"], "sek"); pw.f_old.setText("x"); pw.f_new.setText("yenisifre"); pw.f_new2.setText("yenisifre"); pw._try_accept()
check("Mevcut şifre hatalı" in pw.error.text() and db.authenticate("sek", "123456"), "şifre değiştir: eski şifre yanlışsa değişmez")
pw.f_old.setText("123456"); pw._try_accept()
check(db.authenticate("sek", "yenisifre") and not db.authenticate("sek", "123456"), "şifre değiştir: başarıyla değişti")

# tedavi / röntgen doğrulamaları
t = TreatmentDialog(db, p.saved_id); t.f_proc.setCurrentText(""); t._try_accept()
check("İşlem adı zorunludur" in t.error.text(), "tedavi: işlem adı boşsa uyarı")
t.f_proc.setCurrentText("Dolgu"); t.f_teeth.setText("99"); t._try_accept()
check("geçerli bir FDI" in t.error.text(), "tedavi: geçersiz diş numarası uyarısı")
t.f_teeth.setText("16, 26"); t.f_fee.setValue(1200.5); t._try_accept()
check(t.saved_id and db.get_tooth_status(p.saved_id) == {16: "Dolgu", 26: "Dolgu"}, "tedavi: kayıt + diş şeması güncellendi")
x = XrayDialog(db, p.saved_id); x._try_accept()
check("en az bir röntgen" in x.error.text(), "röntgen: dosya seçilmediyse uyarı")

# açık hasta yokken doktor yoksa randevu uyarısı
db2 = dbm.DB(tempfile.mkdtemp()); pid = db2.save_patient({"full_name": "A"})
from dialogs import AppointmentDialog
a = AppointmentDialog(db2, patient_id=pid); a._try_accept()
check("doktor ekleyin" in a.error.text(), "randevu: doktor yoksa yönlendirici uyarı")
print("\nTÜM DİYALOG AKIŞLARI GEÇTİ")
