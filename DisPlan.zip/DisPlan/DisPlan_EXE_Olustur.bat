@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Tek tikla calisan program (DisPlan.exe) uretir. Python kurulu olmayan bilgisayarlara da kopyalanabilir.
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
if not exist .venv\Scripts\python.exe (
  %PY% -m venv .venv
  .venv\Scripts\python -m pip install --upgrade pip
  .venv\Scripts\python -m pip install -r requirements.txt
)
.venv\Scripts\python -m pip install pyinstaller
.venv\Scripts\pyinstaller --noconfirm --clean --windowed --name DisPlan app.py
if errorlevel 1 (echo Derleme basarisiz oldu. & pause & exit /b 1)
echo.
echo Hazir: dist\DisPlan\DisPlan.exe  (dist\DisPlan klasorunun tamamini kopyalayin)
pause
