"""DişPlan - veri katmanı (SQLite).

Arayüzden bağımsızdır; tek başına test edilebilir.
Tüm tarihler veritabanında ISO (YYYY-MM-DD) biçiminde saklanır.
"""
import datetime as dt
import hashlib
import os
import secrets
import shutil
import sqlite3
import zipfile

# ----------------------------------------------------------------- sabitler
STATUSES = ["Bekliyor", "Geldi", "Tamamlandı", "İptal", "Gelmedi"]
ROLES = {"admin": "Yönetici", "doktor": "Doktor", "sekreter": "Sekreter"}
GENDERS = ["Kadın", "Erkek", "Belirtilmemiş"]
BLOOD_TYPES = ["", "A Rh+", "A Rh-", "B Rh+", "B Rh-", "AB Rh+", "AB Rh-", "0 Rh+", "0 Rh-"]
XRAY_KINDS = ["Panoramik", "Periapikal", "Bitewing", "Sefalometrik", "CBCT / Tomografi", "Diğer"]
SPECIALTIES = ["Genel Diş Hekimi", "Ortodonti", "Endodonti", "Periodontoloji",
               "Oral ve Maksillofasiyal Cerrahi", "Pedodonti", "Protetik Diş Tedavisi", "İmplantoloji"]

TOOTH_STATUSES = ["Sağlam", "Çürük", "Dolgu", "Kanal Tedavisi", "Kaplama / Kron",
                  "İmplant", "Çekilmiş / Eksik", "Planlanan Tedavi"]
DEFAULT_TOOTH_STATUS = "Sağlam"

PROCEDURES = ["Muayene", "Kontrol", "Diş Taşı Temizliği", "Dolgu", "Kanal Tedavisi",
              "Diş Çekimi", "Kron / Kaplama", "İmplant", "Protez", "Ortodonti (Tel Tedavisi)",
              "Beyazlatma", "Cerrahi", "Fluorlu Uygulama", "Fissür Örtücü"]
# Bir işlem kaydedilince ilgili dişin şemadaki durumu otomatik güncellenir.
PROCEDURE_TOOTH_STATUS = {
    "Dolgu": "Dolgu",
    "Kanal Tedavisi": "Kanal Tedavisi",
    "Diş Çekimi": "Çekilmiş / Eksik",
    "Kron / Kaplama": "Kaplama / Kron",
    "İmplant": "İmplant",
}

# FDI diş numaralaması: kalıcı (11-48) ve süt dişleri (51-85)
PERMANENT_TEETH = [q * 10 + n for q in (1, 2, 3, 4) for n in range(1, 9)]
DECIDUOUS_TEETH = [q * 10 + n for q in (5, 6, 7, 8) for n in range(1, 6)]
VALID_TEETH = set(PERMANENT_TEETH) | set(DECIDUOUS_TEETH)

PATIENT_FIELDS = ["tc_no", "full_name", "birth_date", "gender", "phone", "email", "address",
                  "blood_type", "allergies", "chronic_diseases", "medications", "notes"]


# ------------------------------------------------------------ yardımcılar
def data_dir():
    """Verilerin tutulduğu klasör. DISPLAN_DATA ortam değişkeniyle değiştirilebilir."""
    base = os.environ.get("DISPLAN_DATA")
    if not base:
        root = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), ".local", "share")
        base = os.path.join(root, "DisPlan")
    os.makedirs(base, exist_ok=True)
    return base


def today_iso():
    return dt.date.today().isoformat()


def fmt_date(iso):
    if not iso:
        return ""
    try:
        return dt.date.fromisoformat(iso).strftime("%d.%m.%Y")
    except ValueError:
        return iso


def parse_date(text):
    text = (text or "").strip().replace("/", ".").replace("-", ".")
    for fmt in ("%d.%m.%Y", "%d.%m.%y"):
        try:
            return dt.datetime.strptime(text, fmt).date().isoformat()
        except ValueError:
            pass
    raise ValueError("Tarih GG.AA.YYYY biçiminde olmalı (örn. 25.12.2026).")


def norm_time(text):
    t = (text or "").strip().replace(".", ":")
    try:
        h, m = t.split(":")
        h, m = int(h), int(m)
        if 0 <= h < 24 and 0 <= m < 60:
            return f"{h:02d}:{m:02d}"
    except ValueError:
        pass
    raise ValueError("Saat SS:DD biçiminde olmalı (örn. 14:30).")


def minutes(hhmm):
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


def age_from(iso):
    try:
        b = dt.date.fromisoformat(iso)
    except (TypeError, ValueError):
        return None
    t = dt.date.today()
    return t.year - b.year - ((t.month, t.day) < (b.month, b.day))


_TR_MAP = str.maketrans("çğıöşüÇĞİÖŞÜ", "cgiosuCGiOSU")


def fold(s):
    """Türkçe harfleri sadeleştirip küçültür: 'Ayşe' -> 'ayse' (arama için)."""
    return (s or "").translate(_TR_MAP).lower()


_TR_ORDER = {c: 1000 + i for i, c in enumerate("abcçdefgğhıijklmnoöpqrsştuüvwxyz")}


def tr_key(s):
    """Türkçe alfabe sırası için sıralama anahtarı (a b c ç d … ı i … o ö p r s ş t u ü v y z).
    SQLite'ın NOCASE sıralaması yalnızca ASCII bildiği için Ç/Ğ/İ/Ö/Ş/Ü ile başlayan isimleri sona atar."""
    s = (s or "").replace("I", "ı").replace("İ", "i").lower()
    return [_TR_ORDER.get(c, ord(c)) for c in s]


def valid_tc(tc):
    if len(tc) != 11 or not tc.isdigit() or tc[0] == "0":
        return False
    d = [int(c) for c in tc]
    if ((sum(d[0:9:2]) * 7) - sum(d[1:8:2])) % 10 != d[9]:
        return False
    return sum(d[:10]) % 10 == d[10]


def parse_teeth(text):
    """'36, 37' -> [36, 37]. Geçersiz numarada ValueError."""
    out = []
    for part in (text or "").replace(";", ",").replace(" ", ",").split(","):
        part = part.strip()
        if not part:
            continue
        if not part.isdigit() or int(part) not in VALID_TEETH:
            raise ValueError(f"'{part}' geçerli bir FDI diş numarası değil (örn. 16, 24, 36, 48).")
        out.append(int(part))
    return out


def _hash(password, salt_hex):
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), 200_000).hex()


SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, full_name TEXT NOT NULL,
    role TEXT NOT NULL, salt TEXT NOT NULL, pw_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS doctors(
    id INTEGER PRIMARY KEY, full_name TEXT NOT NULL, specialty TEXT DEFAULT '',
    phone TEXT DEFAULT '', active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS patients(
    id INTEGER PRIMARY KEY, tc_no TEXT DEFAULT '', full_name TEXT NOT NULL, birth_date TEXT DEFAULT '',
    gender TEXT DEFAULT '', phone TEXT DEFAULT '', email TEXT DEFAULT '', address TEXT DEFAULT '',
    blood_type TEXT DEFAULT '', allergies TEXT DEFAULT '', chronic_diseases TEXT DEFAULT '',
    medications TEXT DEFAULT '', notes TEXT DEFAULT '', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS appointments(
    id INTEGER PRIMARY KEY,
    patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    doctor_id INTEGER REFERENCES doctors(id),
    date TEXT NOT NULL, time TEXT NOT NULL, duration_min INTEGER NOT NULL DEFAULT 30,
    procedure TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'Bekliyor', notes TEXT DEFAULT '',
    created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_appt_date ON appointments(date, doctor_id);
CREATE INDEX IF NOT EXISTS ix_appt_patient ON appointments(patient_id);
CREATE TABLE IF NOT EXISTS treatments(
    id INTEGER PRIMARY KEY,
    patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    doctor_id INTEGER REFERENCES doctors(id),
    date TEXT NOT NULL, tooth_no TEXT DEFAULT '', procedure TEXT NOT NULL, notes TEXT DEFAULT '',
    fee REAL NOT NULL DEFAULT 0, paid REAL NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS ix_treat_patient ON treatments(patient_id, date);
CREATE TABLE IF NOT EXISTS xrays(
    id INTEGER PRIMARY KEY,
    patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    doctor_id INTEGER REFERENCES doctors(id),
    date TEXT NOT NULL, kind TEXT DEFAULT '', tooth_no TEXT DEFAULT '', notes TEXT DEFAULT '',
    file_path TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_xray_patient ON xrays(patient_id, date);
CREATE TABLE IF NOT EXISTS tooth_status(
    patient_id INTEGER NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    tooth_no INTEGER NOT NULL, status TEXT NOT NULL,
    PRIMARY KEY(patient_id, tooth_no));
"""


class DB:
    def __init__(self, base=None):
        self.base = base or data_dir()
        os.makedirs(self.base, exist_ok=True)
        self.xray_dir = os.path.join(self.base, "xrays")
        os.makedirs(self.xray_dir, exist_ok=True)
        self.path = os.path.join(self.base, "displan.db")
        self.con = sqlite3.connect(self.path)
        self.con.row_factory = sqlite3.Row
        self.con.execute("PRAGMA foreign_keys=ON")
        self.con.executescript(SCHEMA)
        self.con.commit()

    # -- düşük seviye
    def q(self, sql, args=()):
        return self.con.execute(sql, args).fetchall()

    def one(self, sql, args=()):
        return self.con.execute(sql, args).fetchone()

    def ex(self, sql, args=()):
        cur = self.con.execute(sql, args)
        self.con.commit()
        return cur.lastrowid

    def close(self):
        self.con.close()

    # -- kullanıcılar
    def user_count(self):
        return self.one("SELECT COUNT(*) c FROM users")["c"]

    def create_user(self, username, full_name, role, password):
        username = (username or "").strip().lower()
        if not username or not (full_name or "").strip():
            raise ValueError("Kullanıcı adı ve ad soyad zorunludur.")
        if role not in ROLES:
            raise ValueError("Geçersiz rol.")
        if len(password or "") < 6:
            raise ValueError("Şifre en az 6 karakter olmalı.")
        if self.one("SELECT 1 FROM users WHERE username=?", (username,)):
            raise ValueError("Bu kullanıcı adı zaten kullanılıyor.")
        salt = secrets.token_hex(16)
        return self.ex("INSERT INTO users(username,full_name,role,salt,pw_hash) VALUES(?,?,?,?,?)",
                       (username, full_name.strip(), role, salt, _hash(password, salt)))

    def authenticate(self, username, password):
        row = self.one("SELECT * FROM users WHERE username=? AND active=1",
                       ((username or "").strip().lower(),))
        if row and secrets.compare_digest(row["pw_hash"], _hash(password or "", row["salt"])):
            return row
        return None

    def list_users(self):
        return sorted(self.q("SELECT * FROM users"), key=lambda r: tr_key(r["full_name"]))

    def set_password(self, uid, password):
        if len(password or "") < 6:
            raise ValueError("Şifre en az 6 karakter olmalı.")
        salt = secrets.token_hex(16)
        self.ex("UPDATE users SET salt=?, pw_hash=? WHERE id=?", (salt, _hash(password, salt), uid))

    def set_user_active(self, uid, active):
        if not active:
            left = self.one("SELECT COUNT(*) c FROM users WHERE active=1 AND role='admin' AND id<>?", (uid,))["c"]
            target = self.one("SELECT role FROM users WHERE id=?", (uid,))
            if target and target["role"] == "admin" and left == 0:
                raise ValueError("Son aktif yönetici hesabı pasifleştirilemez.")
        self.ex("UPDATE users SET active=? WHERE id=?", (1 if active else 0, uid))

    # -- doktorlar
    def list_doctors(self, active_only=True):
        sql = "SELECT * FROM doctors" + (" WHERE active=1" if active_only else "")
        return sorted(self.q(sql), key=lambda r: tr_key(r["full_name"]))

    def get_doctor(self, did):
        return self.one("SELECT * FROM doctors WHERE id=?", (did,))

    def save_doctor(self, data, did=None):
        name = (data.get("full_name") or "").strip()
        if not name:
            raise ValueError("Doktor adı zorunludur.")
        vals = (name, data.get("specialty") or "", data.get("phone") or "")
        if did:
            self.ex("UPDATE doctors SET full_name=?, specialty=?, phone=? WHERE id=?", vals + (did,))
            return did
        return self.ex("INSERT INTO doctors(full_name,specialty,phone) VALUES(?,?,?)", vals)

    def set_doctor_active(self, did, active):
        self.ex("UPDATE doctors SET active=? WHERE id=?", (1 if active else 0, did))

    def default_doctor_id(self, pid=None):
        """Hastanın son baktığı doktor; yoksa listedeki ilk aktif doktor."""
        if pid:
            r = self.one("SELECT doctor_id FROM treatments WHERE patient_id=? AND doctor_id IS NOT NULL "
                         "ORDER BY date DESC, id DESC LIMIT 1", (pid,))
            if r:
                return r["doctor_id"]
            r = self.one("SELECT doctor_id FROM appointments WHERE patient_id=? AND doctor_id IS NOT NULL "
                         "ORDER BY date DESC, time DESC LIMIT 1", (pid,))
            if r:
                return r["doctor_id"]
        docs = self.list_doctors()
        return docs[0]["id"] if docs else None

    # -- hastalar
    def get_patient(self, pid):
        return self.one("SELECT * FROM patients WHERE id=?", (pid,))

    def save_patient(self, data, pid=None):
        d = {k: (data.get(k) or "").strip() if isinstance(data.get(k), str) or data.get(k) is None
             else data.get(k) for k in PATIENT_FIELDS}
        if not d["full_name"]:
            raise ValueError("Ad Soyad zorunludur.")
        if d["tc_no"]:
            if not valid_tc(d["tc_no"]):
                raise ValueError("TC Kimlik No geçersiz (11 haneli ve doğrulanabilir olmalı). "
                                 "Yabancı uyruklu hastalarda alanı boş bırakıp pasaport no'yu notlara yazın.")
            dup = self.one("SELECT id, full_name FROM patients WHERE tc_no=? AND id IS NOT ?", (d["tc_no"], pid))
            if dup:
                raise ValueError(f"Bu TC Kimlik No ile kayıtlı hasta zaten var: {dup['full_name']}")
        if pid:
            sets = ", ".join(f"{k}=?" for k in PATIENT_FIELDS)
            self.ex(f"UPDATE patients SET {sets} WHERE id=?", [d[k] for k in PATIENT_FIELDS] + [pid])
            return pid
        cols = ", ".join(PATIENT_FIELDS + ["created_at"])
        marks = ", ".join("?" * (len(PATIENT_FIELDS) + 1))
        return self.ex(f"INSERT INTO patients({cols}) VALUES({marks})",
                       [d[k] for k in PATIENT_FIELDS] + [dt.datetime.now().isoformat(timespec="seconds")])

    def delete_patient(self, pid):
        self.ex("DELETE FROM patients WHERE id=?", (pid,))
        shutil.rmtree(os.path.join(self.xray_dir, str(pid)), ignore_errors=True)

    def search_patients(self, text=""):
        """Ad, TC veya telefona göre ara (Türkçe harf duyarsız). Son işlem ve doktorla birlikte döner."""
        rows = self.q("""
            SELECT p.id, p.full_name, p.tc_no, p.phone, p.birth_date,
              (SELECT t.date FROM treatments t WHERE t.patient_id=p.id ORDER BY t.date DESC, t.id DESC LIMIT 1) AS last_date,
              (SELECT t.procedure FROM treatments t WHERE t.patient_id=p.id ORDER BY t.date DESC, t.id DESC LIMIT 1) AS last_proc,
              (SELECT d.full_name FROM treatments t LEFT JOIN doctors d ON d.id=t.doctor_id
                 WHERE t.patient_id=p.id ORDER BY t.date DESC, t.id DESC LIMIT 1) AS last_doctor
            FROM patients p""")
        rows = sorted(rows, key=lambda r: tr_key(r["full_name"]))
        needle = fold(text.strip())
        if not needle:
            return rows
        return [r for r in rows if needle in fold(r["full_name"]) or needle in (r["tc_no"] or "")
                or needle.replace(" ", "") in (r["phone"] or "").replace(" ", "")]

    def patient_summary(self, pid):
        last = self.one("""SELECT t.date, t.procedure, t.tooth_no, d.full_name AS doctor
                           FROM treatments t LEFT JOIN doctors d ON d.id=t.doctor_id
                           WHERE t.patient_id=? ORDER BY t.date DESC, t.id DESC LIMIT 1""", (pid,))
        visit_appt = self.one("""SELECT a.date, d.full_name AS doctor FROM appointments a
                                 LEFT JOIN doctors d ON d.id=a.doctor_id
                                 WHERE a.patient_id=? AND a.status IN ('Geldi','Tamamlandı')
                                 ORDER BY a.date DESC, a.time DESC LIMIT 1""", (pid,))
        last_visit, doctor = "", ""
        cands = []
        if last:
            cands.append((last["date"], last["doctor"] or ""))
        if visit_appt:
            cands.append((visit_appt["date"], visit_appt["doctor"] or ""))
        if cands:
            last_visit, doctor = max(cands, key=lambda c: c[0])
        nxt = self.one("""SELECT a.date, a.time, d.full_name AS doctor, a.procedure FROM appointments a
                          LEFT JOIN doctors d ON d.id=a.doctor_id
                          WHERE a.patient_id=? AND a.status='Bekliyor' AND a.date>=?
                          ORDER BY a.date, a.time LIMIT 1""", (pid, today_iso()))
        bal = self.one("SELECT COALESCE(SUM(fee),0) - COALESCE(SUM(paid),0) AS b FROM treatments WHERE patient_id=?", (pid,))
        xc = self.one("SELECT COUNT(*) c FROM xrays WHERE patient_id=?", (pid,))
        return {"last": last, "doctor": doctor, "last_visit": last_visit, "next": nxt,
                "balance": bal["b"], "xray_count": xc["c"]}

    # -- randevular
    def get_appointment(self, aid):
        return self.one("SELECT * FROM appointments WHERE id=?", (aid,))

    def appointments_on(self, date_iso, doctor_id=None):
        sql = """SELECT a.*, p.full_name AS patient, p.phone AS phone, d.full_name AS doctor
                 FROM appointments a JOIN patients p ON p.id=a.patient_id
                 LEFT JOIN doctors d ON d.id=a.doctor_id WHERE a.date=?"""
        args = [date_iso]
        if doctor_id:
            sql += " AND a.doctor_id=?"
            args.append(doctor_id)
        return self.q(sql + " ORDER BY a.time, a.id", args)

    def patient_appointments(self, pid):
        return self.q("""SELECT a.*, d.full_name AS doctor FROM appointments a
                         LEFT JOIN doctors d ON d.id=a.doctor_id
                         WHERE a.patient_id=? ORDER BY a.date DESC, a.time DESC""", (pid,))

    def find_conflict(self, doctor_id, date_iso, time, duration, exclude_id=None):
        if not doctor_id:
            return None
        start = minutes(time)
        end = start + int(duration)
        rows = self.q("""SELECT a.*, p.full_name AS patient FROM appointments a
                         JOIN patients p ON p.id=a.patient_id
                         WHERE a.doctor_id=? AND a.date=? AND a.status NOT IN ('İptal','Gelmedi')
                         AND a.id IS NOT ?""", (doctor_id, date_iso, exclude_id))
        for r in rows:
            s = minutes(r["time"])
            e = s + r["duration_min"]
            if start < e and s < end:
                return r
        return None

    def save_appointment(self, data, aid=None):
        if not data.get("patient_id"):
            raise ValueError("Hasta seçilmedi.")
        status = data.get("status") or "Bekliyor"
        if status not in STATUSES:
            raise ValueError("Geçersiz randevu durumu.")
        vals = (data["patient_id"], data.get("doctor_id") or None, data["date"], norm_time(data["time"]),
                int(data.get("duration_min") or 30), data.get("procedure") or "", status, data.get("notes") or "")
        if aid:
            self.ex("""UPDATE appointments SET patient_id=?, doctor_id=?, date=?, time=?, duration_min=?,
                       procedure=?, status=?, notes=? WHERE id=?""", vals + (aid,))
            return aid
        return self.ex("""INSERT INTO appointments(patient_id,doctor_id,date,time,duration_min,procedure,status,notes,created_at)
                          VALUES(?,?,?,?,?,?,?,?,?)""", vals + (dt.datetime.now().isoformat(timespec="seconds"),))

    def set_appointment_status(self, aid, status):
        if status not in STATUSES:
            raise ValueError("Geçersiz randevu durumu.")
        self.ex("UPDATE appointments SET status=? WHERE id=?", (status, aid))

    def delete_appointment(self, aid):
        self.ex("DELETE FROM appointments WHERE id=?", (aid,))

    # -- tedaviler
    def get_treatment(self, tid):
        return self.one("SELECT * FROM treatments WHERE id=?", (tid,))

    def list_treatments(self, pid):
        return self.q("""SELECT t.*, d.full_name AS doctor FROM treatments t
                         LEFT JOIN doctors d ON d.id=t.doctor_id
                         WHERE t.patient_id=? ORDER BY t.date DESC, t.id DESC""", (pid,))

    def treatments_for_tooth(self, pid, tooth):
        out = []
        for r in self.list_treatments(pid):
            try:
                if tooth in parse_teeth(r["tooth_no"]):
                    out.append(r)
            except ValueError:
                pass
        return out

    def save_treatment(self, data, tid=None):
        proc = (data.get("procedure") or "").strip()
        if not proc:
            raise ValueError("İşlem adı zorunludur.")
        teeth = parse_teeth(data.get("tooth_no"))
        fee, paid = float(data.get("fee") or 0), float(data.get("paid") or 0)
        if fee < 0 or paid < 0:
            raise ValueError("Tutarlar negatif olamaz.")
        vals = (data["patient_id"], data.get("doctor_id") or None, data["date"],
                ", ".join(str(t) for t in teeth), proc, data.get("notes") or "", fee, paid)
        if tid:
            self.ex("""UPDATE treatments SET patient_id=?, doctor_id=?, date=?, tooth_no=?, procedure=?,
                       notes=?, fee=?, paid=? WHERE id=?""", vals + (tid,))
        else:
            tid = self.ex("""INSERT INTO treatments(patient_id,doctor_id,date,tooth_no,procedure,notes,fee,paid)
                             VALUES(?,?,?,?,?,?,?,?)""", vals)
        new_status = PROCEDURE_TOOTH_STATUS.get(proc)
        if new_status:
            for t in teeth:
                self.set_tooth_status(data["patient_id"], t, new_status)
        return tid

    def delete_treatment(self, tid):
        self.ex("DELETE FROM treatments WHERE id=?", (tid,))

    # -- diş şeması
    def get_tooth_status(self, pid):
        return {r["tooth_no"]: r["status"] for r in
                self.q("SELECT tooth_no, status FROM tooth_status WHERE patient_id=?", (pid,))}

    def set_tooth_status(self, pid, tooth, status):
        if tooth not in VALID_TEETH:
            raise ValueError("Geçersiz diş numarası.")
        if status not in TOOTH_STATUSES:
            raise ValueError("Geçersiz diş durumu.")
        if status == DEFAULT_TOOTH_STATUS:
            self.ex("DELETE FROM tooth_status WHERE patient_id=? AND tooth_no=?", (pid, tooth))
        else:
            self.ex("INSERT OR REPLACE INTO tooth_status(patient_id,tooth_no,status) VALUES(?,?,?)",
                    (pid, tooth, status))

    # -- röntgenler
    def get_xray(self, xid):
        return self.one("SELECT * FROM xrays WHERE id=?", (xid,))

    def list_xrays(self, pid):
        return self.q("""SELECT x.*, d.full_name AS doctor FROM xrays x
                         LEFT JOIN doctors d ON d.id=x.doctor_id
                         WHERE x.patient_id=? ORDER BY x.date DESC, x.id DESC""", (pid,))

    def xray_abs_path(self, rel):
        return os.path.join(self.xray_dir, rel)

    def add_xray(self, pid, src_path, data):
        teeth = parse_teeth(data.get("tooth_no"))
        folder = os.path.join(self.xray_dir, str(pid))
        os.makedirs(folder, exist_ok=True)
        ext = os.path.splitext(src_path)[1].lower() or ".img"
        name = f"{dt.datetime.now():%Y%m%d_%H%M%S}_{secrets.token_hex(3)}{ext}"
        shutil.copy2(src_path, os.path.join(folder, name))
        rel = os.path.join(str(pid), name)
        return self.ex("""INSERT INTO xrays(patient_id,doctor_id,date,kind,tooth_no,notes,file_path,created_at)
                          VALUES(?,?,?,?,?,?,?,?)""",
                       (pid, data.get("doctor_id") or None, data["date"], data.get("kind") or "",
                        ", ".join(str(t) for t in teeth), data.get("notes") or "", rel,
                        dt.datetime.now().isoformat(timespec="seconds")))

    def delete_xray(self, xid):
        r = self.get_xray(xid)
        if r:
            try:
                os.remove(self.xray_abs_path(r["file_path"]))
            except OSError:
                pass
        self.ex("DELETE FROM xrays WHERE id=?", (xid,))

    # -- yedekleme
    def backup(self, dest_zip, include_xrays=True):
        tmp = os.path.join(self.base, "_yedek_gecici.db")
        if os.path.exists(tmp):
            os.remove(tmp)
        dst = sqlite3.connect(tmp)
        try:
            self.con.backup(dst)
        finally:
            dst.close()
        try:
            with zipfile.ZipFile(dest_zip, "w", zipfile.ZIP_DEFLATED) as z:
                z.write(tmp, "displan.db")
                if include_xrays:
                    for root, _, files in os.walk(self.xray_dir):
                        for f in files:
                            full = os.path.join(root, f)
                            z.write(full, os.path.join("xrays", os.path.relpath(full, self.xray_dir)))
        finally:
            os.remove(tmp)

    def restore(self, zip_path):
        """Yedek zip'ini geri yükler. Bağlantı kapatılır; çağıran uygulamayı yeniden başlatmalıdır."""
        with zipfile.ZipFile(zip_path) as z:
            names = [n.replace("\\", "/") for n in z.namelist()]
            if "displan.db" not in names:
                raise ValueError("Bu dosya geçerli bir DişPlan yedeği değil (displan.db bulunamadı).")
            tmp_db = os.path.join(self.base, "_geri_yukleme_gecici.db")
            with z.open("displan.db") as src, open(tmp_db, "wb") as out:
                shutil.copyfileobj(src, out)
            try:
                chk = sqlite3.connect(tmp_db)
                ok = chk.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
                has = chk.execute("SELECT COUNT(*) FROM sqlite_master WHERE name IN ('patients','treatments','appointments')").fetchone()[0] == 3
                chk.close()
            except sqlite3.DatabaseError:
                ok = has = False
            if not (ok and has):
                os.remove(tmp_db)
                raise ValueError("Yedek dosyası bozuk veya DişPlan veritabanı içermiyor. Mevcut verilere dokunulmadı.")
            self.con.close()
            safety = os.path.join(self.base, f"displan_geri_yukleme_oncesi_{dt.datetime.now():%Y%m%d_%H%M%S}.db")
            shutil.copy2(self.path, safety)
            os.replace(tmp_db, self.path)
            xroot = os.path.normpath(self.xray_dir) + os.sep
            for raw, n in zip(z.namelist(), names):
                if not n.startswith("xrays/") or n.endswith("/"):
                    continue
                target = os.path.normpath(os.path.join(self.base, n))
                if not target.startswith(xroot):  # zip-slip koruması
                    continue
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with z.open(raw) as src, open(target, "wb") as out:
                    shutil.copyfileobj(src, out)
        return safety

    def auto_backup(self, keep=10):
        """Günde bir kez, yalnızca veritabanını yedekler (röntgensiz, hafif). Son `keep` yedek tutulur."""
        d = os.path.join(self.base, "backups")
        os.makedirs(d, exist_ok=True)
        name = os.path.join(d, f"displan_otomatik_{dt.date.today():%Y%m%d}.zip")
        if not os.path.exists(name):
            self.backup(name, include_xrays=False)
        files = sorted(f for f in os.listdir(d) if f.startswith("displan_otomatik_"))
        for f in files[:-keep]:
            os.remove(os.path.join(d, f))
        return name
