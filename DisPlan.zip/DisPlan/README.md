# DişPlan — Özel Diş Klinikleri İçin Randevu ve Hasta Takip Uygulaması

Windows için masaüstü uygulaması (Python + PySide6, yerel SQLite veritabanı). İnternet gerekmez; veriler klinik bilgisayarında kalır.

## Neler var?
- **Randevu takvimi:** gün gün görünüm, doktora göre süzme, durum renkleri (Bekliyor / Geldi / Tamamlandı / İptal / Gelmedi), **aynı doktora çakışan randevu uyarısı**.
- **Hasta kartı:** kimlik ve iletişim, alerji / kronik hastalık / ilaç (kırmızı uyarı kutusu), kan grubu, notlar.
- **Kartın üstünde tek bakışta:** son yapılan işlem (tarih + işlemi yapan doktor), son bakan doktor, sonraki randevu, kalan borç, röntgen sayısı.
- **Diş şeması (FDI numaralama):** 32 kalıcı + 20 süt dişi; renk ve harflerle durum (çürük, dolgu, kanal, kron, implant, eksik, planlanan). Dolgu/kanal/çekim/kron/implant işlemi kaydedilince diş durumu otomatik güncellenir. Dişe tıklayınca o dişin işlem geçmişi görünür.
- **Tedavi geçmişi:** tarih, diş, işlem, **tedaviyi yapan doktor**, ücret / ödenen / kalan.
- **Röntgen arşivi:** panoramik, periapikal, bitewing, sefalometrik, CBCT; küçük resim galerisi; büyütme, parlaklık, kontrast, negatif görünüm; doktor, tarih, ilgili diş ve bulgu notu.
- **Randevu → işlem akışı:** randevuyu "Tamamlandı" yapınca yapılan işlemi kayda eklemeyi önerir; böylece "en son ne yapıldı" bilgisi güncel kalır.
- **Roller:** Yönetici (her şey, doktor/kullanıcı yönetimi, yedek) • Doktor (hasta, tedavi, röntgen, randevu) • Sekreter (hasta kaydı ve randevu; tedavi/röntgen yalnızca görüntüler).
- **Yedekleme:** her gün otomatik (veritabanı) + elle tam yedek (veritabanı + röntgenler) + yedekten geri yükleme.
- Türkçe arama (cagla → Çağla), TC Kimlik No doğrulama, Türkçe alfabe sıralaması.

## Kurulum (Windows)
1. Python 3.10 veya üstünü kurun (https://www.python.org/downloads/ — kurulumda **Add python.exe to PATH** kutusunu işaretleyin).
2. `DisPlan_Calistir.bat` dosyasına çift tıklayın. İlk çalıştırmada gerekli paketler kurulur, sonra uygulama açılır.
3. İlk açılışta yönetici hesabını oluşturun, sonra **Doktorlar** sekmesinden doktorları ekleyin.

**Tek tıkla çalışan program (.exe) isterseniz:** `DisPlan_EXE_Olustur.bat` çalıştırın; `dist\DisPlan\DisPlan.exe` oluşur (klasörün tamamını kopyalayın, hedef bilgisayarda Python gerekmez).

## Verileriniz nerede?
`%APPDATA%\DisPlan` klasöründe: `displan.db` (kayıtlar), `xrays\` (röntgen dosyaları), `backups\` (otomatik yedekler). Dosya > Yedek Al ile tam yedeği harici diske / buluta kopyalayın.

## Bilmeniz gerekenler
- **Tek bilgisayar içindir.** Veritabanını ağ klasöründen birden çok bilgisayarla paylaşmayın (SQLite için güvenli değil). Çok bilgisayarlı resepsiyon için sunucu tabanlı bir sürüm gerekir.
- **KVKK:** hasta kayıtları özel nitelikli kişisel veridir. Bilgisayarda BitLocker (disk şifreleme) açın, güçlü şifre kullanın, aydınlatma metni / açık rıza süreçlerinizi ayrıca yürütün. Uygulama veritabanını şifrelemez.
- **DICOM (.dcm)** dosyaları saklanır ama uygulama içinde önizlenmez ("Harici programda aç" ile açılır). PNG/JPG/BMP/TIFF önizlenir.
- Tıbbi karar destek yazılımı değildir; kayıt tutma ve randevu aracıdır.
- Şifreler PBKDF2-SHA256 ile saklanır; şifre unutulursa yönetici sıfırlayabilir. Tek yönetici şifresini unutursa kurtarma yolu yoktur — yedek alın.

## Geliştirme
`python tests/test_db.py` (veri katmanı), `python tests/ui_flows.py` ve `python tests/ui_smoke.py <klasör>` (arayüz; sanal ekranda ekran görüntüleri üretir).
Dosyalar: `db.py` (veri), `widgets.py` (diş şeması, röntgen görüntüleyici), `dialogs.py`, `card.py` (hasta kartı), `app.py` (ana pencere).
